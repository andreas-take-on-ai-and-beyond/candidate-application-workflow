/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql;

import com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeBean;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;

import static com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksSubsystemSQLProducer.fromDatabaseType;

public class QuarkusUserTasksSubsystemMigrationSQLQueriesProducer {

    @ApplicationScoped
    @Produces
    public UserTasksMigrationSQLQueries produce(DataBaseTypeBean dataBaseType, TaskDefinitionCteSQLStatement  cteTaskDefinition) {
        return fromDatabaseType(dataBaseType.getType(), cteTaskDefinition);
    }
}
