/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.sql.cte;

import jakarta.enterprise.inject.Instance;
import jakarta.enterprise.inject.Produces;
import org.kie.kogito.usertask.UserTasks;

import java.util.Optional;

public class QuarkusTaskDefinitionCteSQLStatementProducer {

    @Produces
    public TaskDefinitionCteSQLStatement cteTaskDefinition(Instance<UserTasks> userTasks) {
        return TaskDefinitionCteSQLStatementProducer.buildTaskDefinitionCteSQLStatement(userTasks.isResolvable() ? userTasks.stream().findFirst() : Optional.empty());
    }
}
