/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.database;

public class DataBaseTypeBean {
    private DataBaseType type;

    DataBaseTypeBean() {
        this(null);
    }

    public DataBaseTypeBean(DataBaseType type) {
        this.type = type;
    }

    public DataBaseType getType() {
        return type;
    }
}
