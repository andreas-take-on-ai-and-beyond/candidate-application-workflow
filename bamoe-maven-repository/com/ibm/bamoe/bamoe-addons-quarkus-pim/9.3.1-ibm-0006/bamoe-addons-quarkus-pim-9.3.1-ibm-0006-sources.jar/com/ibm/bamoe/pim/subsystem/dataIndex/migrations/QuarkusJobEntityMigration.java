/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusJobEntityMigration extends JobEntityMigration {

    // CDI
    public QuarkusJobEntityMigration() {
        this(null);
    }

    @Inject
    public QuarkusJobEntityMigration(DataSource dataSource) {
        super(dataSource);
    }
}
