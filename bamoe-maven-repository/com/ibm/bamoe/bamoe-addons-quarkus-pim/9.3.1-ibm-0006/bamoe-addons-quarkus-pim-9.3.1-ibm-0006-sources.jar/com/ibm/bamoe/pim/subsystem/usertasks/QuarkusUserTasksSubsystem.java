/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks;

import com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksMigrationSQLQueries;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.kie.kogito.usertask.UserTasks;

import javax.sql.DataSource;

@Transactional
public class QuarkusUserTasksSubsystem extends UserTasksSubsystem {

    //CDI
    QuarkusUserTasksSubsystem() {
        super();
    }

    @Inject
    public QuarkusUserTasksSubsystem(DataSource dataSource, Instance<UserTasks> userTasksInstance, UserTasksMigrationSQLQueries queries) {
        super(dataSource, userTasksInstance.isResolvable() ?  userTasksInstance.get() : null, queries);
    }
}
