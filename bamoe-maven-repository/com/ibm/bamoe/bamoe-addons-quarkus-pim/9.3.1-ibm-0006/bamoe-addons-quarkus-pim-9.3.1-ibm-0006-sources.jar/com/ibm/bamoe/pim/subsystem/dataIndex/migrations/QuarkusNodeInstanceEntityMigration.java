/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusNodeInstanceEntityMigration extends NodeInstanceEntityMigration {

    // CDI
    public QuarkusNodeInstanceEntityMigration() {
        this(null, null);
    }

    @Inject
    public QuarkusNodeInstanceEntityMigration(DataSource dataSource, DataIndexNodeInstanceEntityMigrationSQLQueries queries) {
        super(dataSource, queries);
    }
}
