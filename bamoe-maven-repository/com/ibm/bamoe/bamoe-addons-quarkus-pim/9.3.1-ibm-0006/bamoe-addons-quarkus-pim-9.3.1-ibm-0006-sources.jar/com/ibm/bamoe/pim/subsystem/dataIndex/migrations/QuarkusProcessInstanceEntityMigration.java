/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.kie.kogito.process.Processes;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusProcessInstanceEntityMigration extends ProcessInstanceEntityMigration {

    // CDI
    public QuarkusProcessInstanceEntityMigration() {
        this(null, null);
    }

    @Inject
    public QuarkusProcessInstanceEntityMigration(DataSource dataSource, Processes processes) {
        super(dataSource, processes);
    }
}
