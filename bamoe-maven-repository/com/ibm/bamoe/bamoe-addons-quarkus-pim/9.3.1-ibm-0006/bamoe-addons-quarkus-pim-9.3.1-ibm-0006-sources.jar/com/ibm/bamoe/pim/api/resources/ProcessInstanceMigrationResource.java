/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import com.ibm.bamoe.pim.api.model.PlanSpec;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;

import io.quarkus.narayana.jta.runtime.TransactionConfiguration;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

@ApplicationScoped
@Path("/pim")
public class ProcessInstanceMigrationResource extends BaseProcessInstanceMigrationResource<Response> {

    // CDI
    public ProcessInstanceMigrationResource() {
        this(null);
    }

    @Inject
    public ProcessInstanceMigrationResource(ProcessInstanceMigrationManagementService pimManagementService) {
        super(pimManagementService);
    }

    @Override
    protected Response buildOkResponse(String message, Object data) {
        SuccessResponse response = new SuccessResponse(message, 200, data);
        return Response.ok(response).build();
    }

    @Override
    protected Response buildCreatedResponse(String message, Object data) {
        SuccessResponse response = new SuccessResponse(message, 201, data);
        return Response.status(Response.Status.CREATED).entity(response).build();
    }

    @Override
    protected Response badRequestResponse(String message) {
        ErrorResponse error = new ErrorResponse(Status.BAD_REQUEST.getStatusCode(), Status.BAD_REQUEST.getReasonPhrase(), message);
        return Response.status(Response.Status.BAD_REQUEST).entity(error).build();
    }

    @Override
    protected Response badRequestResponse(String message, Object data) {
        ErrorResponse error = new ErrorResponse(Status.BAD_REQUEST.getStatusCode(), Status.BAD_REQUEST.getReasonPhrase(), message, data);
        return Response.status(Response.Status.BAD_REQUEST).entity(error).build();
    }

    @Override
    protected Response notFoundResponse(String message) {
        ErrorResponse error = new ErrorResponse(Status.NOT_FOUND.getStatusCode(), Status.NOT_FOUND.getReasonPhrase(), message);
        return Response.status(Response.Status.NOT_FOUND).entity(error).build();
    }

    @Override
    @POST
    @Path("plan")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Response createPlan(PlanSpec planSpec) {
        return doCreatePlan(planSpec);
    }

    @Override
    @GET
    @Path("plan/{planId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPlan(@PathParam("planId") String planId) {
        return doGetPlan(planId);
    }

    @Override
    @GET
    @Path("plans")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPlans(@QueryParam("sourceProcessId") String sourceProcessId, @QueryParam("targetProcessId") String targetProcessId) {
        return doGetPlans(sourceProcessId, targetProcessId);
    }

    @Override
    @DELETE
    @Path("plan/{planId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    public Response deletePlan(@PathParam("planId") String planId) {
        return doDeletePlan(planId);
    }

    @Override
    @POST
    @Path("migration")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Transactional
    @TransactionConfiguration(timeout = 3600, timeoutFromConfigProperty = "bamoe.pim.transaction-timeout")
    public Response migrateProcessInstance(ProcessInstanceMigrationSpec processInstanceMigrationSpec) {
        return doMigrateProcessInstance(processInstanceMigrationSpec);
    }

    @Override
    @GET
    @Path("migration/processes/{processInstanceId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMigratedProcessInstances(@PathParam("processInstanceId") String processInstanceId) {
        return doGetMigratedProcessInstance(processInstanceId);
    }
}
