/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusJDBCProcessInstanceMigrationRepository extends JDBCProcessInstanceMigrationRepository {

    // CDI
    QuarkusJDBCProcessInstanceMigrationRepository() {
        this(null);
    }

    @Inject
    public QuarkusJDBCProcessInstanceMigrationRepository(DataSource dataSource) {
        super(dataSource);
    }
}
