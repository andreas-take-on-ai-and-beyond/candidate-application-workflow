/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.migration.event.MigrationEventPublisher;
import com.ibm.bamoe.pim.migration.event.NewMigrationEvent;
import com.ibm.bamoe.pim.subsystem.SubsystemMigrator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Event;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
@Transactional
public class QuarkusMigrationEventPublisher implements MigrationEventPublisher {

    private final SubsystemMigrator subsystemMigrator;

    @Inject
    public QuarkusMigrationEventPublisher(SubsystemMigrator subsystemMigrator) {
        this.subsystemMigrator = subsystemMigrator;
    }

    @Override
    public void onNewMigration(NewMigrationEvent event) {
        this.subsystemMigrator.migrate(event);
    }
}
