/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@ApplicationScoped
@Transactional
public class QuarkusSubsystemMigrator extends BaseSubsystemMigrator {

    // CDI
    public QuarkusSubsystemMigrator() {
    }

    @Inject
    public QuarkusSubsystemMigrator(Instance<BamoeSubsystem> subsystems) {
        super(subsystems);
    }
}
