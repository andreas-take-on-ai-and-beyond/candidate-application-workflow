/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
/*
 *
 */

package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.kie.kogito.event.DataEvent;

import java.util.Collection;

@ApplicationScoped
public class QuarkusProcessInstanceMigrationEventPublisher extends ProcessInstanceMigrationEventPublisher {

    // CDI
    QuarkusProcessInstanceMigrationEventPublisher() {
        this(null);
    }

    @Inject
    public QuarkusProcessInstanceMigrationEventPublisher(ProcessInstanceMigrationsRepository migrationsRepository) {
        super(migrationsRepository);
    }

    @Override
    @Transactional(Transactional.TxType.REQUIRED)
    public void publish(DataEvent<?> event) {
        super.publish(event);
    }

    @Override
    @Transactional(Transactional.TxType.REQUIRED)
    public void publish(Collection<DataEvent<?>> events) {
        super.publish(events);
    }
}
