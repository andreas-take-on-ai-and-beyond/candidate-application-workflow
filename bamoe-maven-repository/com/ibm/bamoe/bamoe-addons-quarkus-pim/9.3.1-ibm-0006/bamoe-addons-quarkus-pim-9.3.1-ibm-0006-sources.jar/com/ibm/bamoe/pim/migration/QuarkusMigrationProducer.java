/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;

@ApplicationScoped
public class QuarkusMigrationProducer {

    @Inject
    ProcessInstanceMigrationsRepository pimRepository;

    @Inject
    ProcessInstanceMigrationPlanRepository processInstanceMigrationPlanRepository;

    @Produces
    @ApplicationScoped
    ProcessInstanceMigrationExecutor processInstanceMigrationService() {
        return new ProcessInstanceMigrationExecutor(pimRepository, processInstanceMigrationPlanRepository);
    }

}
