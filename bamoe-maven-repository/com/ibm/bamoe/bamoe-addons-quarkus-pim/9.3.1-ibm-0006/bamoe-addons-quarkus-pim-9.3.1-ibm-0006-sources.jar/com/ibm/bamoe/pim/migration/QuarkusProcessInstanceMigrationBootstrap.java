/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import io.quarkus.runtime.Startup;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;


@Startup
@ApplicationScoped
public class QuarkusProcessInstanceMigrationBootstrap {
  
    @Inject
    ProcessInstanceMigrationExecutor pimService;

    @PostConstruct
    public void init() {
        ProcessInstanceMigrationServiceHolder.setService(pimService);
    }
}
