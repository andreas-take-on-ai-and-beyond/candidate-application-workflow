/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.kie.kogito.usertask.UserTasks;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusUserTaskInstanceEntityMigration extends UserTaskInstanceEntityMigration {

    // CDI
    public QuarkusUserTaskInstanceEntityMigration() {
        super();
    }

    @Inject
    public QuarkusUserTaskInstanceEntityMigration(DataSource dataSource, Instance<UserTasks> userTasksInstance, DataIndexUserTaskInstanceEntityMigrationSQLQueries queries) {
        super(dataSource, userTasksInstance.isResolvable() ?  userTasksInstance.get() : null, queries);
    }
}
