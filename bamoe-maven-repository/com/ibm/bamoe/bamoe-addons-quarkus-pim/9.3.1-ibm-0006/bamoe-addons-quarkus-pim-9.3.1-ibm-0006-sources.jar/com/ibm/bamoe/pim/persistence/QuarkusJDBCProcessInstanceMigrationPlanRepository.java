/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import javax.sql.DataSource;

@ApplicationScoped
@Transactional
public class QuarkusJDBCProcessInstanceMigrationPlanRepository extends JDBCProcessInstanceMigrationPlanRepository {

    // CDI
    QuarkusJDBCProcessInstanceMigrationPlanRepository() {
        this(null);
    }

    @Inject
    public QuarkusJDBCProcessInstanceMigrationPlanRepository(DataSource dataSource) {
        super(dataSource);
    }
}
