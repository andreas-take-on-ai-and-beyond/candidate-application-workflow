/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex;

import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.JobEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.NodeInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.ProcessInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.UserTaskInstanceEntityMigration;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@Transactional
public class QuarkusDataIndexSubsystem extends DataIndexSubsystem {

    //CDI
    QuarkusDataIndexSubsystem() {
        super();
    }

    @Inject
    public QuarkusDataIndexSubsystem(ProcessInstanceEntityMigration processInstances,
            UserTaskInstanceEntityMigration userTasks, NodeInstanceEntityMigration nodeInstances,
            JobEntityMigration jobs) {
        super(processInstances, userTasks, nodeInstances, jobs);
    }
}
