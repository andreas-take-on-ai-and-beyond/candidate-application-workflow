/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.database;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;

import javax.sql.DataSource;

import static com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeHelper.lookupDataBaseType;

public class QuarkusDataBaseTypeProducer {

    @ApplicationScoped
    @Produces
    public DataBaseTypeBean produceDataBaseType(DataSource dataSource) {
        DataBaseType type = lookupDataBaseType(dataSource);
        return new DataBaseTypeBean(type);
    }
}
