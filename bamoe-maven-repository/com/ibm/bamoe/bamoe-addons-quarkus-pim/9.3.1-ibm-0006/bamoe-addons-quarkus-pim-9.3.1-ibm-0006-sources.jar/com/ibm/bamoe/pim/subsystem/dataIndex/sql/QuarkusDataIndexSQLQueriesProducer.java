/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql;

import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeBean;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.DataIndexSubsystemSQLQueriesProducer.getNodeInstanceEntityMigrationFromDatabaseType;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.DataIndexSubsystemSQLQueriesProducer.getUserTaskInstanceEntityMigrationSQLQueriesFromDataBaseType;

public class QuarkusDataIndexSQLQueriesProducer {

    @ApplicationScoped
    @Produces
    public DataIndexUserTaskInstanceEntityMigrationSQLQueries getUserTaskInstanceEntityMigrationSQLQueries(DataBaseTypeBean dataBaseType, TaskDefinitionCteSQLStatement cteTaskDefinition) {
        return getUserTaskInstanceEntityMigrationSQLQueriesFromDataBaseType(dataBaseType.getType(), cteTaskDefinition);
    }

    @ApplicationScoped
    @Produces
    public DataIndexNodeInstanceEntityMigrationSQLQueries nodeInstanceEntityMigrationSQLFromDataBaseType(DataBaseTypeBean dataBaseType) {
        return getNodeInstanceEntityMigrationFromDatabaseType(dataBaseType.getType());
    }
}
