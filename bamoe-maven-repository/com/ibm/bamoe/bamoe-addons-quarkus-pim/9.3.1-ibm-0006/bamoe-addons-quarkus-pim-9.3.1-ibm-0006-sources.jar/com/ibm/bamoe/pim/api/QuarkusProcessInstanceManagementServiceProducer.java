/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api;

import com.ibm.bamoe.pim.api.service.PlanSpecValidatorImpl;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementServiceImpl;
import com.ibm.bamoe.pim.migration.event.MigrationEventPublisher;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeBean;
import com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeHelper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.kie.kogito.process.Processes;

@ApplicationScoped
public class QuarkusProcessInstanceManagementServiceProducer {

    @Produces
    public ProcessInstanceMigrationManagementService producePIMManagementService(Processes processes, ProcessInstanceMigrationPlanRepository pimMigrationPlansRepository, ProcessInstanceMigrationsRepository pimMigrationsRepository, MigrationEventPublisher migrationEventPublisher, ProcessInstanceMigrationManagementService.Configuration configuration) {
        return new ProcessInstanceMigrationManagementServiceImpl(processes, new PlanSpecValidatorImpl(processes), pimMigrationPlansRepository, pimMigrationsRepository, migrationEventPublisher, configuration);
    }

    @Produces
    public ProcessInstanceMigrationManagementService.Configuration producePIMManagementServiceConfiguration(DataBaseTypeBean dataBaseTypeBean) {
        return DataBaseTypeHelper.createDbSpecificServiceConfiguration(dataBaseTypeBean.getType());
    }
}
