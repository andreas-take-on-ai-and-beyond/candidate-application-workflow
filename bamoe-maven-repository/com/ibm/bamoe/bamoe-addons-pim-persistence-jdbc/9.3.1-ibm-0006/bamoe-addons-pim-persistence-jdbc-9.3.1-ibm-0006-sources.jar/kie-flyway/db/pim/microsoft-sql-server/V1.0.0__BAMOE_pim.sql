-- IBM Confidential
-- PID 5900-AR4
-- Copyright IBM Corp. 2025  
CREATE TABLE bamoe_process_instance_migration_plans (
  id CHAR(36) NOT NULL,
  source_process_id VARCHAR(255) NOT NULL,
  source_process_version VARCHAR(255) NOT NULL,
  target_process_id VARCHAR(255) NOT NULL,
  target_process_version VARCHAR(255) NOT NULL,
  updated_at DATETIME,
  CONSTRAINT pk_migration_plans PRIMARY KEY (id)
);

CREATE TABLE bamoe_process_instance_migration_plan_node_mappings (
  process_instance_migration_plan_id CHAR(36) NOT NULL,
  source_id VARCHAR(128) NOT NULL,
  target_id VARCHAR(128) NOT NULL,
  PRIMARY KEY (process_instance_migration_plan_id, source_id, target_id),
  FOREIGN KEY (process_instance_migration_plan_id) REFERENCES bamoe_process_instance_migration_plans(id) ON DELETE CASCADE
);

CREATE TABLE bamoe_process_instance_migration (
  migration_id CHAR(36) NOT NULL,
  process_instance_id CHAR(36) NOT NULL,
  process_instance_migration_plan_id CHAR(36) NOT NULL,
  created_at DATETIME,
  applied_at DATETIME,
  CONSTRAINT pk_migration PRIMARY KEY (process_instance_id, process_instance_migration_plan_id, migration_id),
  CONSTRAINT fk_migration_plan FOREIGN KEY (process_instance_migration_plan_id)
    REFERENCES bamoe_process_instance_migration_plans(id) ON DELETE CASCADE
);

CREATE INDEX idx_bamoe_process_instance_migration_pid ON bamoe_process_instance_migration(process_instance_id);
CREATE INDEX idx_bamoe_process_instance_migration_mid ON bamoe_process_instance_migration(migration_id);
CREATE INDEX idx_bamoe_process_instance_migration_at ON bamoe_process_instance_migration(applied_at);
CREATE INDEX idx_bamoe_process_instance_migration_mpid ON bamoe_process_instance_migration(process_instance_migration_plan_id);

CREATE INDEX idx_bamoe_migration_plans_node_mappings_mpid ON bamoe_process_instance_migration_plan_node_mappings(process_instance_migration_plan_id);
CREATE INDEX idx_bamoe_migration_plans_node_mappings_source_id ON bamoe_process_instance_migration_plan_node_mappings(source_id);
CREATE INDEX idx_bamoe_migration_plans_node_mappings_target_id ON bamoe_process_instance_migration_plan_node_mappings(target_id);