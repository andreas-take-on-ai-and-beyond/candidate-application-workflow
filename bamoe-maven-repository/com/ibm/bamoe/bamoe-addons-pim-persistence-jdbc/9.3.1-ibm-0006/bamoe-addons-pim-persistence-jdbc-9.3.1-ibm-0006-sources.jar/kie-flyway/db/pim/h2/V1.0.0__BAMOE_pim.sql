-- IBM Confidential
-- PID 5900-AR4
-- Copyright IBM Corp. 2025  
CREATE TABLE bamoe_process_instance_migration_plans (
  id VARCHAR(36) NOT NULL,
  source_process_id VARCHAR(50) NOT NULL,
  source_process_version VARCHAR(50) NOT NULL,
  target_process_id VARCHAR(50) NOT NULL,
  target_process_version VARCHAR(50) NOT NULL,
  updated_at TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE bamoe_process_instance_migration_plan_node_mappings (
  process_instance_migration_plan_id VARCHAR(36) NOT NULL,
  source_id VARCHAR(128) NOT NULL,
  target_id VARCHAR(128) NOT NULL,
  PRIMARY KEY (process_instance_migration_plan_id, source_id, target_id),
  FOREIGN KEY (process_instance_migration_plan_id) REFERENCES bamoe_process_instance_migration_plans(id) ON DELETE CASCADE
);

CREATE TABLE bamoe_process_instance_migration (
  migration_id VARCHAR(36) NOT NULL,
  process_instance_id VARCHAR(36) NOT NULL,
  process_instance_migration_plan_id VARCHAR(36) NOT NULL,
  created_at TIMESTAMP,
  applied_at TIMESTAMP,
  PRIMARY KEY (process_instance_id, process_instance_migration_plan_id, migration_id),
  FOREIGN KEY (process_instance_migration_plan_id)
    REFERENCES bamoe_process_instance_migration_plans(id) ON DELETE CASCADE
);

CREATE INDEX idx_bamoe_process_instance_migration_pid ON bamoe_process_instance_migration(process_instance_id);
CREATE INDEX idx_bamoe_process_instance_migration_mid ON bamoe_process_instance_migration(migration_id);
CREATE INDEX idx_bamoe_process_instance_migration_at ON bamoe_process_instance_migration(applied_at);
CREATE INDEX idx_bamoe_process_instance_migration_mpid ON bamoe_process_instance_migration(process_instance_migration_plan_id);

CREATE INDEX idx_bamoe_migration_plans_node_mappings_mpid ON bamoe_process_instance_migration_plan_node_mappings(process_instance_migration_plan_id);
CREATE INDEX idx_bamoe_migration_plans_node_mappings_source_id ON bamoe_process_instance_migration_plan_node_mappings(source_id);
CREATE INDEX idx_bamoe_migration_plans_node_mappings_target_id ON bamoe_process_instance_migration_plan_node_mappings(target_id);