/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.model.PlanSpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static java.util.UUID.randomUUID;

public class JDBCProcessInstanceMigrationPlanRepository implements ProcessInstanceMigrationPlanRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCProcessInstanceMigrationPlanRepository.class);

    static final String INSERT_PLAN_STATEMENT = "INSERT INTO bamoe_process_instance_migration_plans (id, source_process_id, source_process_version, target_process_id, target_process_version, updated_at) VALUES (?, ?, ?, ?, ?, ?) ";

    static final String INSERT_NODE_MAPPINGS_STATEMENT = "INSERT INTO bamoe_process_instance_migration_plan_node_mappings (process_instance_migration_plan_id, source_id, target_id) VALUES (?, ?, ?)";

    static final String SELECT_PLANS_QUERY = "SELECT id, source_process_id, source_process_version, target_process_id, target_process_version, updated_at FROM bamoe_process_instance_migration_plans WHERE ";

    static final String SELECT_PLANS_BY_ID_QUERY = SELECT_PLANS_QUERY + " id = ?";

    static final String SELECT_NODE_MAPPINGS_BY_PLAN_ID = "SELECT source_id, target_id FROM bamoe_process_instance_migration_plan_node_mappings WHERE process_instance_migration_plan_id = ? ";

    static final String DELETE_PLANS_BY_ID_STATEMENT = "DELETE FROM bamoe_process_instance_migration_plans WHERE id = ?";

    private final DataSource dataSource;

    public JDBCProcessInstanceMigrationPlanRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public int delete(String planId) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(DELETE_PLANS_BY_ID_STATEMENT)) {
            stmt.setString(1, planId);
            return stmt.executeUpdate();
        } catch (Exception ex) {
            throw throwUnhandled("Error deleting migration plan with id %s".formatted(planId), ex);
        }
    }

    @Override
    public Optional<MigrationPlan> findById(String planId) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(SELECT_PLANS_BY_ID_QUERY);) {
            stmt.setString(1, planId);
            try (ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(from(resultSet));
                }
            }
            return Optional.empty();
        } catch (Exception ex) {
            throw throwUnhandled("Couldn't find migration plan with id %s".formatted(planId), ex);
        }
    }

    private MigrationPlan from(ResultSet resultSet) throws SQLException {
        MigrationPlan migrationPlan = new MigrationPlan();
        migrationPlan.setId(resultSet.getString(1));
        migrationPlan.setSourceProcessId(resultSet.getString(2));
        migrationPlan.setSourceProcessVersion(resultSet.getString(3));
        migrationPlan.setTargetProcessId(resultSet.getString(4));
        migrationPlan.setTargetProcessVersion(resultSet.getString(5));
        migrationPlan.setUpdatedAt(resultSet.getTimestamp(6));
        migrationPlan.setNodeMapping(getNodeMappingsByPlanId(migrationPlan.getId()));
        return migrationPlan;
    }

    private Collection<NodeMapping> getNodeMappingsByPlanId(String planId) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(SELECT_NODE_MAPPINGS_BY_PLAN_ID)) {
            stmt.setString(1, planId);

            List<NodeMapping> toReturn = new ArrayList<>();
            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    toReturn.add(new NodeMapping(resultSet.getString(1), resultSet.getString(2)));
                }
            }
            return toReturn;
        } catch (Exception ex) {
            throw throwUnhandled("Couldn't find node mappings for migration plan with id %s".formatted(planId), ex);
        }
    }

    @Override
    public MigrationPlan create(PlanSpec planSpec) {

        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(INSERT_PLAN_STATEMENT);
                PreparedStatement mappingsStmt = con.prepareStatement(INSERT_NODE_MAPPINGS_STATEMENT)) {

            MigrationPlan migrationPlan = new MigrationPlan();
            migrationPlan.setId(randomUUID().toString());
            migrationPlan.setSourceProcessId(planSpec.getSourceProcessId());
            migrationPlan.setSourceProcessVersion(planSpec.getSourceProcessVersion());
            migrationPlan.setTargetProcessId(planSpec.getTargetProcessId());
            migrationPlan.setTargetProcessVersion(planSpec.getTargetProcessVersion());
            migrationPlan.setNodeMapping(planSpec.getNodeMapping());
            migrationPlan.setUpdatedAt(new Date());

            stmt.setString(1, migrationPlan.getId());
            stmt.setString(2, migrationPlan.getSourceProcessId());
            stmt.setString(3, migrationPlan.getSourceProcessVersion());
            stmt.setString(4, migrationPlan.getTargetProcessId());
            stmt.setString(5, migrationPlan.getTargetProcessVersion());
            stmt.setDate(6, new java.sql.Date(migrationPlan.getUpdatedAt().getTime()));

            stmt.executeUpdate();

            if (migrationPlan.getNodeMapping() != null) {
                for (NodeMapping nodeMapping : migrationPlan.getNodeMapping()) {
                    mappingsStmt.setString(1, migrationPlan.getId());
                    mappingsStmt.setString(2, nodeMapping.getSourceId());
                    mappingsStmt.setString(3, nodeMapping.getTargetId());
                    mappingsStmt.addBatch();
                }
                mappingsStmt.executeBatch();
            }
            return migrationPlan;
        } catch (Exception ex) {
            throw throwUnhandled("Error creating migration plan for spec %s@%s to %s@%s".formatted(planSpec.getSourceProcessId(), planSpec.getSourceProcessVersion(), planSpec.getTargetProcessId(),
                    planSpec.getTargetProcessVersion()), ex);
        }
    }

    @Override
    public Collection<MigrationPlan> findBySourceAndTarget(String sourceProcessId, String targetProcessId) {
        StringBuilder selectPlans = new StringBuilder(SELECT_PLANS_QUERY)
                .append("1=1");

        if (sourceProcessId != null && !sourceProcessId.isEmpty()) {
            selectPlans.append(" AND source_process_id = ?");
        }

        if (targetProcessId != null && !targetProcessId.isEmpty()) {
            selectPlans.append(" AND target_process_id = ?");
        }

        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(selectPlans.toString());) {

            int i = 1;
            if (sourceProcessId != null && !sourceProcessId.isEmpty()) {
                stmt.setString(i++, sourceProcessId);
            }
            if (targetProcessId != null && !targetProcessId.isEmpty()) {
                stmt.setString(i, targetProcessId);
            }

            List<MigrationPlan> toReturn = new ArrayList<>();

            try (ResultSet resultSet = stmt.executeQuery()) {
                while (resultSet.next()) {
                    toReturn.add(from(resultSet));
                }
            }
            return toReturn;
        } catch (Exception ex) {
            throw throwUnhandled("Couldn't find migration plans for sourceProcessId %s and targetProcessId %s".formatted(sourceProcessId, targetProcessId), ex);
        }
    }

    private RuntimeException throwUnhandled(String message, Exception ex) {
        LOGGER.error(message, ex);
        return new RuntimeException(message, ex);
    }
}
