/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import com.ibm.bamoe.pim.api.model.ProcessInstanceMigration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class JDBCProcessInstanceMigrationRepository implements ProcessInstanceMigrationsRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCProcessInstanceMigrationRepository.class);

    static final String SELECT_PIMS = "SELECT migration_id, process_instance_id, process_instance_migration_plan_id, created_at, applied_at FROM bamoe_process_instance_migration ";
    static final String SELECT_PIMS_BY_PROCESS_INSTANCE_ID = SELECT_PIMS + "WHERE process_instance_id = ? ";
    static final String ORDER_BY = "ORDER BY created_at ASC";

    static final String SELECT_PIMS_BY_PROCESS_INSTANCE_ID_QUERY = SELECT_PIMS_BY_PROCESS_INSTANCE_ID + ORDER_BY;
    static final String SELECT_UNAPPLIED_PIMS_BY_PROCESS_INSTANCE_ID_QUERY = SELECT_PIMS_BY_PROCESS_INSTANCE_ID + " AND applied_at IS NULL " + ORDER_BY;
    static final String SELECT_PIMS_BY_PLAN_ID_QUERY = SELECT_PIMS + "WHERE process_instance_migration_plan_id = ?";

    static final String INSERT_PIMS_STATEMENT = "INSERT INTO bamoe_process_instance_migration (migration_id, process_instance_id, process_instance_migration_plan_id, created_at) " +
            "SELECT ?, pi.id, ?, CURRENT_TIMESTAMP FROM process_instances pi WHERE pi.process_id = ? AND pi.process_version = ?";
    static final String INSERT_PIMS_WITH_PIDS_STATEMENT_TEMPLATE = INSERT_PIMS_STATEMENT + " AND pi.id IN (%s)";

    static final String UPDATE_PIM_BY_PID_AND_PLAN_ID_STATEMENT = "UPDATE bamoe_process_instance_migration SET applied_at = ? WHERE process_instance_id = ? and process_instance_migration_plan_id = ?";
    static final String DELETE_PIMS_BY_PID_STATEMENT = "DELETE FROM bamoe_process_instance_migration WHERE process_instance_id = ?";

    private final DataSource dataSource;

    public JDBCProcessInstanceMigrationRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public boolean existMigrationsForPlanId(String planId) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(SELECT_PIMS_BY_PLAN_ID_QUERY);) {
            stmt.setString(1, planId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (Exception ex) {
            throw throwUnhandled("Error getting migrations for plan with id %s".formatted(planId), ex);
        }
    }

    @Override
    public Collection<ProcessInstanceMigration> findMigrationsByProcessInstanceId(String processInstanceId) {
        return findByProcessInstanceId(processInstanceId, SELECT_PIMS_BY_PROCESS_INSTANCE_ID_QUERY);
    }

    @Override
    public Collection<ProcessInstanceMigration> findUnappliedMigrationsByProcessInstanceId(String processInstanceId) {
        return findByProcessInstanceId(processInstanceId, SELECT_UNAPPLIED_PIMS_BY_PROCESS_INSTANCE_ID_QUERY);
    }

    private Collection<ProcessInstanceMigration> findByProcessInstanceId(String processInstanceId, String query) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(query);) {
            stmt.setString(1, processInstanceId);
            List<ProcessInstanceMigration> toReturn = new ArrayList<>();
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    toReturn.add(from(rs));
                }
            }
            return toReturn;
        } catch (Exception ex) {
            throw throwUnhandled("Error getting migrations for processInstanceId %s".formatted(processInstanceId), ex);
        }
    }

    @Override
    public void update(ProcessInstanceMigration migration) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(UPDATE_PIM_BY_PID_AND_PLAN_ID_STATEMENT)) {
            stmt.setTimestamp(1, migration.getAppliedAt() != null ? new java.sql.Timestamp(migration.getAppliedAt().getTime()) : null);
            stmt.setString(2, migration.getProcessInstanceId());
            stmt.setString(3, migration.getPlanId());
            stmt.executeUpdate();
        } catch (Exception ex) {
            throw throwUnhandled("Error updating migrations with id %s for processId %s (%s) planId %s".formatted(migration.getMigrationId(), migration.getProcessInstanceId(), migration.getPlanId()), ex);
        }
    }

    @Override
    public long insertMigrations(String migrationId, String planId, String processId, String processVersion) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(INSERT_PIMS_STATEMENT);) {
            stmt.setString(1, migrationId);
            stmt.setString(2, planId);
            stmt.setString(3, processId);
            stmt.setString(4, processVersion);
            return stmt.executeUpdate();
        } catch (Exception ex) {
            throw throwUnhandled("Error inserting migrations with id %s for processId %s (%s) planId %s".formatted(migrationId, processId, processVersion, planId), ex);
        }
    }

    @Override
    public long insertMigrations(String migrationId, String planId, String processId, String processVersion, Collection<String> processInstanceIds) {
        String sqlParamsPlaceHolders = processInstanceIds.stream()
                .map(processInstanceId -> "?")
                .collect(Collectors.joining(", "));

        String fullInsertTemplate = INSERT_PIMS_WITH_PIDS_STATEMENT_TEMPLATE.formatted(sqlParamsPlaceHolders);

        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(fullInsertTemplate);) {
            stmt.setString(1, migrationId);
            stmt.setString(2, planId);
            stmt.setString(3, processId);
            stmt.setString(4, processVersion);

            int i = 4;
            for (String processInstanceId : processInstanceIds) {
                stmt.setString(++i, processInstanceId);
            }

            return stmt.executeUpdate();
        } catch (Exception ex) {
            throw throwUnhandled("Error inserting migrations with id %s for processId %s (%s) planId %s".formatted(migrationId, processId, processVersion, planId), ex);
        }
    }

    @Override
    public int deleteForProcessInstance(String processInstanceId) {
        try (Connection con = dataSource.getConnection();
                PreparedStatement stmt = con.prepareStatement(DELETE_PIMS_BY_PID_STATEMENT);) {
            stmt.setString(1, processInstanceId);
            return stmt.executeUpdate();
        } catch (Exception ex) {
            throw throwUnhandled("Error deleting migrations for processInstanceId %s".formatted(processInstanceId), ex);
        }
    }

    private ProcessInstanceMigration from(ResultSet rs) throws SQLException {
        ProcessInstanceMigration migration = new ProcessInstanceMigration();
        migration.setMigrationId(rs.getString(1));
        migration.setProcessInstanceId(rs.getString(2));
        migration.setPlanId(rs.getString(3));
        migration.setCreatedAt(new Date(rs.getDate(4).getTime()));
        java.sql.Timestamp appliedAt = rs.getTimestamp(5);
        if (appliedAt != null) {
            migration.setAppliedAt(new Date(appliedAt.getTime()));
        }

        return migration;
    }

    private RuntimeException throwUnhandled(String message, Exception ex) {
        LOGGER.error(message, ex);
        return new RuntimeException(message, ex);
    }
}
