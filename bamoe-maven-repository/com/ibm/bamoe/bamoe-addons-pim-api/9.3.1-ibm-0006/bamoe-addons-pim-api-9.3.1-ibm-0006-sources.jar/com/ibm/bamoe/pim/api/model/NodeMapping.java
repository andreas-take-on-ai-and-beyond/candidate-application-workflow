/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.model;

import java.util.Objects;

public class NodeMapping {
    private String sourceId;
    private String targetId;

    public NodeMapping() {}

    public NodeMapping(String sourceId, String targetId) {
        this.sourceId = sourceId;
        this.targetId = targetId;
    }
    
    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof NodeMapping that)) {
            return false;
        }
        return Objects.equals(getSourceId(), that.getSourceId()) && Objects.equals(getTargetId(), that.getTargetId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSourceId(), getTargetId());
    }

    @Override
    public String toString() {
        return "sourceId=[" + this.sourceId + "], targetId=[" + this.targetId + "]";
    }
}
