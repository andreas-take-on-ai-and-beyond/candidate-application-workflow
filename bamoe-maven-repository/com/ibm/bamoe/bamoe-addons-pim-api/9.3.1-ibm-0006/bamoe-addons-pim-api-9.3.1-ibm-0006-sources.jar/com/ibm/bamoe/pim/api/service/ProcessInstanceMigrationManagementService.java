/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.service;

import com.ibm.bamoe.pim.api.model.*;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.ValidationResult;

import java.util.Collection;
import java.util.Optional;

public interface ProcessInstanceMigrationManagementService {

    record ValidatedPlan(MigrationPlan plan, ValidationResult validationResult) {}

    ValidatedPlan createMigrationPlan(PlanSpec spec);

    Collection<MigrationPlan> findMigrationPlans(String sourceProcessId, String targetProcessId);

    Optional<MigrationPlan> findMigrationPlanById(String planId);

    void deletePlan(String planId);

    MigrationSummary migrateProcessInstances(Collection<String> processInstanceId, String planId);

    MigrationSummary migrateAll(String planId);

    Collection<ProcessInstanceMigration> findMigrationsByProcessInstanceId(String processInstanceId);

    interface Configuration {
        int DEFAULT_MAX_MIGRATION_BULK_SIZE = 50000;
        default int maxMigrationBulkSize() {
            return DEFAULT_MAX_MIGRATION_BULK_SIZE;
        }
    }
}
