/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration.event;

import com.ibm.bamoe.pim.api.model.MigrationPlan;

public class NewMigrationEvent {

    private String migrationId;
    private MigrationPlan migrationPlan;

    public NewMigrationEvent(String migrationId, MigrationPlan migrationPlan) {
        this.migrationId = migrationId;
        this.migrationPlan = migrationPlan;
    }

    public String getMigrationId() {
        return migrationId;
    }

    public MigrationPlan getMigrationPlan() {
        return migrationPlan;
    }
}
