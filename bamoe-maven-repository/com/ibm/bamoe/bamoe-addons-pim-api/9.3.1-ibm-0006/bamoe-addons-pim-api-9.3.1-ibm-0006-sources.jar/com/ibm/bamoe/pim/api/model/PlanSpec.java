/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.model;

import java.util.List;

public class PlanSpec {
    
    private String sourceProcessId;
    private String sourceProcessVersion;
    private String targetProcessId;
    private String targetProcessVersion;
    private List<NodeMapping> nodeMapping;

    public PlanSpec() {
        // 
    }

    public PlanSpec(String sourceProcessId, String sourceProcessVersion, String targetProcessId, String targetProcessVersion) {
        this.sourceProcessId = sourceProcessId;
        this.sourceProcessVersion = sourceProcessVersion;
        this.targetProcessId = targetProcessId;
        this.targetProcessVersion = targetProcessVersion;
    }

    public PlanSpec(String sourceProcessId, String sourceProcessVersion, String targetProcessId, String targetProcessVersion, List<NodeMapping> nodeMapping) {
        this.sourceProcessId = sourceProcessId;
        this.sourceProcessVersion = sourceProcessVersion;
        this.targetProcessId = targetProcessId;
        this.targetProcessVersion = targetProcessVersion;
        this.nodeMapping = nodeMapping;
    }

    public String getSourceProcessId() {
        return sourceProcessId;
    }

    public void setSourceProcessId(String sourceProcessId) {
        this.sourceProcessId = sourceProcessId;
    }

    public String getSourceProcessVersion() {
        return sourceProcessVersion;
    }

    public void setSourceProcessVersion(String sourceProcessVersion) {
        this.sourceProcessVersion = sourceProcessVersion;
    }

    public String getTargetProcessId() {
        return targetProcessId;
    }

    public void setTargetProcessId(String targetProcessId) {
        this.targetProcessId = targetProcessId;
    }

    public String getTargetProcessVersion() {
        return targetProcessVersion;
    }

    public void setTargetProcessVersion(String targetProcessVersion) {
        this.targetProcessVersion = targetProcessVersion;
    }

    public List<NodeMapping> getNodeMapping() {
        return nodeMapping;
    }

    public void setNodeMapping(List<NodeMapping> nodeMapping) {
        this.nodeMapping = nodeMapping;
    }
}
