/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "migrationId", "processInstanceId", "planId", "createdAt", "appliedAt"
})
public class ProcessInstanceMigration {
    private String migrationId;
    private String processInstanceId;
    private String planId;
    private Date createdAt;
    private Date appliedAt;

    public ProcessInstanceMigration() {
    }

    public ProcessInstanceMigration(String migrationId, String processInstanceId, String planId, Date createdAt, Date appliedAt) {
        this.migrationId = migrationId;
        this.processInstanceId = processInstanceId;
        this.planId = planId;
        this.createdAt = createdAt;
        this.appliedAt = appliedAt;
    }

    public String getMigrationId() {
        return migrationId;
    }

    public void setMigrationId(String migrationId) {
        this.migrationId = migrationId;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getAppliedAt() {
        return appliedAt;
    }

    public void setAppliedAt(Date appliedAt) {
        this.appliedAt = appliedAt;
    }
}
