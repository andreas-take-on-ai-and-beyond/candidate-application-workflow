/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.model;

import java.util.Collection;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id", "sourceProcessId", "sourceProcessVersion",
    "targetProcessId", "targetProcessVersion",
    "nodeMapping", "updatedAt"
})
public class MigrationPlan {
    private String id;
    private String sourceProcessId;
    private String sourceProcessVersion;
    private String targetProcessId;
    private String targetProcessVersion;
    private Collection<NodeMapping> nodeMapping;
    private Date updatedAt;

    public MigrationPlan() {
    }

    public MigrationPlan(String id, String sourceProcessId, String sourceProcessVersion, String targetProcessId,
        String targetProcessVersion, Collection<NodeMapping> nodeMapping, Date updatedAt) {
        this.id = id;
        this.sourceProcessId = sourceProcessId;
        this.sourceProcessVersion = sourceProcessVersion;
        this.targetProcessId = targetProcessId;
        this.targetProcessVersion = targetProcessVersion;
        this.nodeMapping = nodeMapping;
        this.updatedAt = updatedAt;
    }

    public String getId() {
      return id;
    }
    public void setId(String id) {
      this.id = id;
    }
    public String getSourceProcessId() {
      return sourceProcessId;
    }
    public void setSourceProcessId(String sourceProcessId) {
      this.sourceProcessId = sourceProcessId;
    }
    public String getSourceProcessVersion() {
      return sourceProcessVersion;
    }
    public void setSourceProcessVersion(String sourceProcessVersion) {
      this.sourceProcessVersion = sourceProcessVersion;
    }
    public String getTargetProcessId() {
      return targetProcessId;
    }
    public void setTargetProcessId(String targetProcessId) {
      this.targetProcessId = targetProcessId;
    }
    public String getTargetProcessVersion() {
      return targetProcessVersion;
    }
    public void setTargetProcessVersion(String targetProcessVersion) {
      this.targetProcessVersion = targetProcessVersion;
    }
    public Collection<NodeMapping> getNodeMapping() {
      return nodeMapping;
    }
    public void setNodeMapping(Collection<NodeMapping> nodeMapping) {
      this.nodeMapping = nodeMapping;
    }
    public Date getUpdatedAt() {
      return updatedAt;
    }
    public void setUpdatedAt(Date updatedAt) {
      this.updatedAt = updatedAt;
    }
}

