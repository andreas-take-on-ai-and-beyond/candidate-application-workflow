/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Collection;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MigrationSummary {

    private String migrationId;
    private String planId;
    private long migratedProcessInstancesCount;
    private Collection<String> skippedProcessInstanceIds;

    public MigrationSummary(String migrationId, String planId, long migratedProcessInstancesCount) {
        this.migrationId = migrationId;
        this.planId = planId;
        this.migratedProcessInstancesCount = migratedProcessInstancesCount;
    }

    public MigrationSummary(String migrationId, String planId, long migratedProcessInstancesCount, Collection<String> skippedProcessInstanceIds) {
        this.migrationId = migrationId;
        this.planId = planId;
        this.migratedProcessInstancesCount = migratedProcessInstancesCount;
        this.skippedProcessInstanceIds = skippedProcessInstanceIds;
    }

    public String getMigrationId() {
        return migrationId;
    }

    public void setMigrationId(String migrationId) {
        this.migrationId = migrationId;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public long getMigratedProcessInstancesCount() {
        return migratedProcessInstancesCount;
    }

    public void setMigratedProcessInstancesCount(long migratedProcessInstancesCount) {
        this.migratedProcessInstancesCount = migratedProcessInstancesCount;
    }

    public Collection<String> getSkippedProcessInstanceIds() {
        return skippedProcessInstanceIds;
    }

    public void setSkippedProcessInstanceIds(Collection<String> skippedProcessInstanceIds) {
        this.skippedProcessInstanceIds = skippedProcessInstanceIds;
    }
}
