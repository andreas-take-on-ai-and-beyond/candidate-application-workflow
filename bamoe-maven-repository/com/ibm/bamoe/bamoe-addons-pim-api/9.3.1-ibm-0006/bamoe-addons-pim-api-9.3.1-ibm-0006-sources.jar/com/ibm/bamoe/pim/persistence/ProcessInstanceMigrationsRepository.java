/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import com.ibm.bamoe.pim.api.model.ProcessInstanceMigration;

import java.util.Collection;

public interface ProcessInstanceMigrationsRepository {

    boolean existMigrationsForPlanId(String planId);

    Collection<ProcessInstanceMigration> findMigrationsByProcessInstanceId(String processInstanceId);

    Collection<ProcessInstanceMigration> findUnappliedMigrationsByProcessInstanceId(String processInstanceId);

    void update(ProcessInstanceMigration migration);

    long insertMigrations(String migrationId, String planId, String processId, String processVersion);

    long insertMigrations(String migrationId, String planId, String processId, String processVersion, Collection<String> processInstanceIds);

    int deleteForProcessInstance(String processInstanceId);
}
