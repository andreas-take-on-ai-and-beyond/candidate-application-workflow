/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration.event;

public interface MigrationEventPublisher {

    void onNewMigration(NewMigrationEvent event);
}
