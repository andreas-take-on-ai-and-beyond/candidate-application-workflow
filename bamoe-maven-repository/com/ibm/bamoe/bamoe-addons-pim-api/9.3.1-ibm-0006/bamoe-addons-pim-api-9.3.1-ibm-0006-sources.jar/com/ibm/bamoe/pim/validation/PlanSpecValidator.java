/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.validation;

import java.util.List;

import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.model.PlanSpec;

public interface PlanSpecValidator {
    public static enum Level {
        WARNING,
        ERROR;
    }

    public static enum Result {
        PASSED,
        FAILED;
    }

    public record ProcessDescriptor(String id, String version) {
    }

    public record ValidationResultReportedItem<T>(T validatedItem, Level level, String message) {
    }

    public record CategorizedReportedItems(List<ValidationResultReportedItem<ProcessDescriptor>> processItems, List<ValidationResultReportedItem<NodeMapping>> nodeMappingItems) {
    }

    public record ValidationResult(Level failureThresholdLevel, Result result, CategorizedReportedItems errors, CategorizedReportedItems warnings) {
    }

    ValidationResult validatePlan(PlanSpec spec);

    ValidationResult validatePlan(PlanSpec spec, Level failureThresholdLevel);
}
