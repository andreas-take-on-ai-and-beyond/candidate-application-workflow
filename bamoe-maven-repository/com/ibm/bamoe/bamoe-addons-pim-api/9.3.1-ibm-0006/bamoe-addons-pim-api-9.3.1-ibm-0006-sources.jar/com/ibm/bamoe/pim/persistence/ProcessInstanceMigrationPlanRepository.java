/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;


import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.api.model.PlanSpec;

import java.util.Collection;
import java.util.Optional;

public interface ProcessInstanceMigrationPlanRepository {

    int delete(String planId);

    Optional<MigrationPlan> findById(String id);

    Collection<MigrationPlan> findBySourceAndTarget(String sourceProcessId, String targetProcessId);

    MigrationPlan create(PlanSpec planSpec);

}
