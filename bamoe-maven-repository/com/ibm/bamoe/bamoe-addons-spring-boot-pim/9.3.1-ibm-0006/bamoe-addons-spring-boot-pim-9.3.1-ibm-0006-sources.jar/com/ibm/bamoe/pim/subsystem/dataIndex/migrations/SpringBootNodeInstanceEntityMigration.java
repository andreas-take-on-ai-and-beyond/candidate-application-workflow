/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import org.kie.kogito.index.jpa.springboot.storage.DataIndexSpringbootConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

@Component
@Transactional
@ConditionalOnClass(DataIndexSpringbootConfiguration.class)
public class SpringBootNodeInstanceEntityMigration extends NodeInstanceEntityMigration {

    @Autowired
    public SpringBootNodeInstanceEntityMigration(DataSource dataSource, DataIndexNodeInstanceEntityMigrationSQLQueries queries) {
        super(dataSource, queries);
    }
}
