/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import org.kie.kogito.index.jpa.springboot.storage.DataIndexSpringbootConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

@Component
@Transactional
@ConditionalOnClass(DataIndexSpringbootConfiguration.class)
public class SpringBootJobEntityMigration extends JobEntityMigration {

    @Autowired
    public SpringBootJobEntityMigration(DataSource dataSource) {
        super(dataSource);
    }
}
