/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex;

import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.JobEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.NodeInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.ProcessInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.UserTaskInstanceEntityMigration;
import org.kie.kogito.index.jpa.springboot.storage.DataIndexSpringbootConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
@ConditionalOnClass(DataIndexSpringbootConfiguration.class)
public class SpringBootDataIndexSubsystem extends DataIndexSubsystem {

    @Autowired
    public SpringBootDataIndexSubsystem(ProcessInstanceEntityMigration processInstances,
            UserTaskInstanceEntityMigration userTasks, NodeInstanceEntityMigration nodeInstances,
            JobEntityMigration jobs) {
        super(processInstances, userTasks, nodeInstances, jobs);
    }
}
