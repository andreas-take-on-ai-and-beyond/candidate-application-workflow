/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;
import org.kie.kogito.index.jpa.springboot.storage.DataIndexSpringbootConfiguration;
import org.kie.kogito.usertask.UserTasks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.Optional;

@Component
@Transactional
@ConditionalOnClass(DataIndexSpringbootConfiguration.class)
public class SpringBootUserTaskInstanceEntityMigration extends UserTaskInstanceEntityMigration {

   @Autowired
    public SpringBootUserTaskInstanceEntityMigration(DataSource dataSource, Optional<UserTasks> userTasksOptional, DataIndexUserTaskInstanceEntityMigrationSQLQueries queries) {
        super(dataSource, userTasksOptional.orElse(null), queries);
    }
}
