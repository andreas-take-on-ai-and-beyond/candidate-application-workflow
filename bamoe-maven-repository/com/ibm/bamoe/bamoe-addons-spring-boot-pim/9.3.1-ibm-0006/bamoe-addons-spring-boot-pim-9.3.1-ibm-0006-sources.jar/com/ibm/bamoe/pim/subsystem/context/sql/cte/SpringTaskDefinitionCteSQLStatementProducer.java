/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.sql.cte;

import org.kie.kogito.usertask.UserTasks;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Optional;

import static com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatementProducer.buildTaskDefinitionCteSQLStatement;

@Configuration
public class SpringTaskDefinitionCteSQLStatementProducer {

    @Bean
    public TaskDefinitionCteSQLStatement taskDefinitionCteSQLStatement(Optional<UserTasks> userTasks) {
        return buildTaskDefinitionCteSQLStatement(userTasks);
    }
}
