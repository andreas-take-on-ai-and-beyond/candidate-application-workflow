/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBootMigrationProducer {

    @Autowired
    private ProcessInstanceMigrationsRepository pimRepository;

    @Autowired
    private ProcessInstanceMigrationPlanRepository processInstanceMigrationPlanRepository;

    @Bean
    public ProcessInstanceMigrationExecutor processInstanceMigrationService() {
        return new ProcessInstanceMigrationExecutor(pimRepository, processInstanceMigrationPlanRepository);
    }

    @Bean
    public ProcessInstanceMigrationEventPublisher processEventListener() {
        return new ProcessInstanceMigrationEventPublisher(pimRepository);
    }
}