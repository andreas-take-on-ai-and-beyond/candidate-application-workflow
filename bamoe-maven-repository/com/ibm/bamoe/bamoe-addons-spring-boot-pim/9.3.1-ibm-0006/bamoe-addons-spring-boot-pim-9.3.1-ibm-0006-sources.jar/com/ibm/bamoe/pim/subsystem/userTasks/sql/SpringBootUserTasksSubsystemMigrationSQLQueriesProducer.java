/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.userTasks.sql;

import com.ibm.bamoe.pim.subsystem.context.database.DataBaseType;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;
import com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksMigrationSQLQueries;
import org.jbpm.usertask.jpa.springboot.SpringBootJPAUserTaskInstances;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksSubsystemSQLProducer.fromDatabaseType;

@Configuration
@ConditionalOnClass(SpringBootJPAUserTaskInstances.class)
public class SpringBootUserTasksSubsystemMigrationSQLQueriesProducer {

    @Bean
    public UserTasksMigrationSQLQueries userTasksMigrationSQLQueries(DataBaseType dataBaseType, TaskDefinitionCteSQLStatement cteTaskDefinition) {
        return fromDatabaseType(dataBaseType, cteTaskDefinition);
    }
}
