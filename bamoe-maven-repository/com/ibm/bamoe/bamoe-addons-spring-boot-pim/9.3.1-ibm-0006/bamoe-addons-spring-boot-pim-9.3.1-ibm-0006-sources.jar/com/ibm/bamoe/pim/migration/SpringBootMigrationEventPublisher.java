/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.migration.event.MigrationEventPublisher;
import com.ibm.bamoe.pim.migration.event.NewMigrationEvent;
import com.ibm.bamoe.pim.subsystem.SubsystemMigrator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class SpringBootMigrationEventPublisher implements MigrationEventPublisher {

    private final SubsystemMigrator subsystemMigrator;

    @Autowired
    public SpringBootMigrationEventPublisher(SubsystemMigrator subsystemMigrator) {
        this.subsystemMigrator = subsystemMigrator;
    }

    @Override
    public void onNewMigration(NewMigrationEvent event) {
        subsystemMigrator.migrate(event);
    }
}
