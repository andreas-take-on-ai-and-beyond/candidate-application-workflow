/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
/*
 *
 */

package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import jakarta.transaction.Transactional;
import org.kie.kogito.event.DataEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class SpringBootProcessInstanceMigrationEventPublisher extends ProcessInstanceMigrationEventPublisher {

    // CDI
    SpringBootProcessInstanceMigrationEventPublisher() {
        this(null);
    }

    @Autowired
    public SpringBootProcessInstanceMigrationEventPublisher(ProcessInstanceMigrationsRepository migrationsRepository) {
        super(migrationsRepository);
    }

    @Override
    @Transactional(Transactional.TxType.REQUIRED)
    public void publish(DataEvent<?> event) {
        super.publish(event);
    }

    @Override
    @Transactional(Transactional.TxType.REQUIRED)
    public void publish(Collection<DataEvent<?>> events) {
        super.publish(events);
    }
}
