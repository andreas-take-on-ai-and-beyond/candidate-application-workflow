/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.database;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

import static com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeHelper.lookupDataBaseType;

@Configuration
public class SpringBootDataBaseTypeProducer {

    @Bean
    public DataBaseType produceDataBaseType(DataSource dataSource) {
        return lookupDataBaseType(dataSource);
    }
}
