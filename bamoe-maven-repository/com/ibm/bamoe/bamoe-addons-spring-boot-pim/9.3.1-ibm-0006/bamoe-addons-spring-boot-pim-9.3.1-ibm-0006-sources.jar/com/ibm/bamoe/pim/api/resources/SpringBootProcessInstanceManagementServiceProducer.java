/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import com.ibm.bamoe.pim.api.service.PlanSpecValidatorImpl;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementServiceImpl;
import com.ibm.bamoe.pim.migration.event.MigrationEventPublisher;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import com.ibm.bamoe.pim.subsystem.context.database.DataBaseType;
import com.ibm.bamoe.pim.subsystem.context.database.DataBaseTypeHelper;
import org.kie.kogito.process.Processes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.Transactional;

@Configuration
public class SpringBootProcessInstanceManagementServiceProducer {

    @Bean
    @Transactional
    public ProcessInstanceMigrationManagementService producePIMManagementService(Processes processes, ProcessInstanceMigrationPlanRepository pimMigrationPlansRepository, ProcessInstanceMigrationsRepository pimMigrationsRepository, MigrationEventPublisher migrationEventPublisher, ProcessInstanceMigrationManagementService.Configuration configuration) {
        return new ProcessInstanceMigrationManagementServiceImpl(processes, new PlanSpecValidatorImpl(processes), pimMigrationPlansRepository, pimMigrationsRepository, migrationEventPublisher, configuration);
    }

    @Bean
    public ProcessInstanceMigrationManagementService.Configuration producePIMManagementServiceConfiguration(DataBaseType dataBaseType) {
        return DataBaseTypeHelper.createDbSpecificServiceConfiguration(dataBaseType);
    }
}