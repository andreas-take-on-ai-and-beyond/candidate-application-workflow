/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class SpringBootSubsystemMigrator extends BaseSubsystemMigrator {

    @Autowired
    public SpringBootSubsystemMigrator(List<BamoeSubsystem> subsystems) {
        super(subsystems);
    }
}
