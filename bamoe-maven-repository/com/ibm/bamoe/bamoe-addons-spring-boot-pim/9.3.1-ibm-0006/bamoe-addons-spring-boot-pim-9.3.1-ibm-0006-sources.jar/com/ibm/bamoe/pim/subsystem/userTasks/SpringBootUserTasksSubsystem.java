/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.userTasks;

import com.ibm.bamoe.pim.subsystem.usertasks.UserTasksSubsystem;
import com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksMigrationSQLQueries;
import org.jbpm.usertask.jpa.springboot.SpringBootJPAUserTaskInstances;
import org.kie.kogito.usertask.UserTasks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.Optional;

@Component
@Transactional
@ConditionalOnClass(SpringBootJPAUserTaskInstances.class)
public class SpringBootUserTasksSubsystem extends UserTasksSubsystem {

    @Autowired
    public SpringBootUserTasksSubsystem(DataSource dataSource, Optional<UserTasks> userTasksOptional, UserTasksMigrationSQLQueries queries) {
        super(dataSource, userTasksOptional.orElse(null), queries);
    }
}
