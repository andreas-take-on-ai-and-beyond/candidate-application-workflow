/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.controller;

import com.ibm.bamoe.pim.api.model.PlanSpec;
import com.ibm.bamoe.pim.api.resources.BaseProcessInstanceMigrationResource;
import com.ibm.bamoe.pim.api.resources.ErrorResponse;
import com.ibm.bamoe.pim.api.resources.ProcessInstanceMigrationSpec;
import com.ibm.bamoe.pim.api.resources.SuccessResponse;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pim")
public class ProcessInstanceMigrationController extends BaseProcessInstanceMigrationResource<ResponseEntity<Object>> {

    @Autowired
    public ProcessInstanceMigrationController(ProcessInstanceMigrationManagementService pimManagementService) {
        super(pimManagementService);
    }

    @Override
    protected ResponseEntity<Object> buildOkResponse(String message, Object data) {
        SuccessResponse response = new SuccessResponse(message, 200, data);
        return ResponseEntity.ok(response);
    }

    @Override
    protected ResponseEntity<Object> buildCreatedResponse(String message, Object data) {
        SuccessResponse response = new SuccessResponse(message, 201, data);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @Override
    protected ResponseEntity<Object> badRequestResponse(String message) {
        ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), message);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @Override
    protected ResponseEntity<Object> badRequestResponse(String message, Object data) {
        ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), message, data);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
    }

    @Override
    protected ResponseEntity<Object> notFoundResponse(String message) {
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase(), message);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }

    @Override
    @PostMapping("plan")
    @Transactional
    public ResponseEntity<Object> createPlan(@RequestBody PlanSpec planSpec) {
        return doCreatePlan(planSpec);
    }

    @Override
    @GetMapping("plan/{planId}")
    public ResponseEntity<Object> getPlan(@PathVariable("planId") String planId) {
        return doGetPlan(planId);
    }

    @Override
    @GetMapping("plans")
    public ResponseEntity<Object> getPlans(@RequestParam(value = "sourceProcessId", required = false) String sourceProcessId, 
                                          @RequestParam(value = "targetProcessId", required = false) String targetProcessId) {
        return doGetPlans(sourceProcessId, targetProcessId);
    }

    @Override
    @DeleteMapping("plan/{planId}")
    @Transactional
    public ResponseEntity<Object> deletePlan(@PathVariable("planId") String planId) {
        return doDeletePlan(planId);
    }

    @Override
    @PostMapping("migration")
    @Transactional
    public ResponseEntity<Object> migrateProcessInstance(@RequestBody ProcessInstanceMigrationSpec processInstanceMigrationSpec) {
        return doMigrateProcessInstance(processInstanceMigrationSpec);
    }

    @Override
    @GetMapping("migration/processes/{processInstanceId}")
    public ResponseEntity<Object> getMigratedProcessInstances(@PathVariable("processInstanceId") String processInstanceId) {
        return doGetMigratedProcessInstance(processInstanceId);
    }
}