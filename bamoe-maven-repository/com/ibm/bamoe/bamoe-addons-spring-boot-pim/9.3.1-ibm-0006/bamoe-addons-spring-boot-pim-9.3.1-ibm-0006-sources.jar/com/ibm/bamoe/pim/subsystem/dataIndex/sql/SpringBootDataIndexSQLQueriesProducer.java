/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql;

import com.ibm.bamoe.pim.subsystem.context.database.DataBaseType;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;
import org.kie.kogito.index.jpa.springboot.storage.DataIndexSpringbootConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.DataIndexSubsystemSQLQueriesProducer.getNodeInstanceEntityMigrationFromDatabaseType;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.DataIndexSubsystemSQLQueriesProducer.getUserTaskInstanceEntityMigrationSQLQueriesFromDataBaseType;

@Configuration
@ConditionalOnClass(DataIndexSpringbootConfiguration.class)
public class SpringBootDataIndexSQLQueriesProducer {

    @Bean
    public DataIndexUserTaskInstanceEntityMigrationSQLQueries userTaskInstanceEntityMigrationSQLQueries(DataBaseType dataBaseType, TaskDefinitionCteSQLStatement cteTaskDefinition) {
        return getUserTaskInstanceEntityMigrationSQLQueriesFromDataBaseType(dataBaseType, cteTaskDefinition);
    }

    @Bean
    public DataIndexNodeInstanceEntityMigrationSQLQueries nodeInstanceEntityMigrationSQLQueries(DataBaseType dataBaseType) {
        return getNodeInstanceEntityMigrationFromDatabaseType(dataBaseType);
    }
}
