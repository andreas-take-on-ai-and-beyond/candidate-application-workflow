/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SpringBootProcessInstanceMigrationBootstrap {
  
    @Autowired
    private ProcessInstanceMigrationExecutor pimService;

    @PostConstruct
    public void init() {
        ProcessInstanceMigrationServiceHolder.setService(pimService);
    }
}