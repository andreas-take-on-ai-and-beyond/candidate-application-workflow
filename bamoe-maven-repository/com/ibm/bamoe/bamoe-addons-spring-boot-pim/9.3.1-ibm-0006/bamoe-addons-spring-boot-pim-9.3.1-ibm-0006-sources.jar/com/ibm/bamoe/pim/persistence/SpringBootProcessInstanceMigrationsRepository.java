/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

@Component
@Transactional
public class SpringBootProcessInstanceMigrationsRepository extends JDBCProcessInstanceMigrationRepository {

    @Autowired
    public SpringBootProcessInstanceMigrationsRepository(DataSource dataSource) {
        super(dataSource);
    }
}
