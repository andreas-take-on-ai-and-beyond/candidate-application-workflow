/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.service;

public class ProcessInstanceMigrationPlanNotFoundException extends RuntimeException {
}
