/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import static java.lang.String.format;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import com.ibm.bamoe.pim.api.model.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationPlanInUseException;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationPlanNotFoundException;
import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService.ValidatedPlan;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.ProcessDescriptor;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.Result;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.ValidationResult;

public abstract class BaseProcessInstanceMigrationResource<T> implements ProcessInstanceMigrationResourceInterface<T> {

    private static final String MESSAGE_CHECK_LOGS = "Please check the logs for more information.";
    private static final String MESSAGE_FAIL_CREATE_PLAN = "Failed to create a process instance migration plan.";
    private static final String MESSAGE_FAIL_RETRIEVE_PLAN = "Failed to retrieve process instance migration plan.";
    private static final String MESSAGE_FAIL_RETRIEVE_PLANS = "Failed to retrieve process instance migration plans.";
    private static final String MESSAGE_FAIL_DELETE_PLAN = "Failed to delete a process instance migration plan.";
    private static final String MESSAGE_FAIL_RETRIEVE_INSTANCE_AFTER_MIGRATION = "Failed to retrieve migrated process instance.";
    private static final String MESSAGE_MIGRATION_FAILED = "Migration failed.";

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseProcessInstanceMigrationResource.class);

    protected ProcessInstanceMigrationManagementService pimManagementService;

    public BaseProcessInstanceMigrationResource(ProcessInstanceMigrationManagementService pimManagementService) {
        this.pimManagementService = pimManagementService;
    }

    public T doCreatePlan(PlanSpec planSpec) {
        try {
            ValidatedPlan validatedPlan = pimManagementService.createMigrationPlan(planSpec);
            if (validatedPlan.validationResult().result() == Result.PASSED && validatedPlan.plan() != null) {
                LOGGER.info("Created plan with id ({})", validatedPlan.plan().getId());
                return buildCreatedResponse("Created process instance migration plan", new ValidatedPlanResponse(validatedPlan.plan(), buildValidationResultResponseObject(validatedPlan.validationResult())));
            } else {
                String message = "Migration plan validation " + validatedPlan.validationResult().result().name() + " and migration plan was NOT created.";
                LOGGER.info(message);
                LOGGER.debug("Validation results: {}", validatedPlan.validationResult());
                return badRequestResponse(message, new ValidatedPlanResponse(validatedPlan.plan(), buildValidationResultResponseObject(validatedPlan.validationResult())));
            }
        } catch (Exception e) {
            LOGGER.error(MESSAGE_FAIL_CREATE_PLAN, e);
            return badRequestResponse(MESSAGE_FAIL_CREATE_PLAN + " " + MESSAGE_CHECK_LOGS);
        }
    }

    public T doGetPlan(String planId) {
        try {
            Optional<MigrationPlan> migrationPlanOptional = pimManagementService.findMigrationPlanById(planId);
            if (migrationPlanOptional.isEmpty()) {
                return notFoundResponse("Migration plan not found. id: '" + planId + "'");
            }

            return buildOkResponse("Retrieved process instance migration plan", migrationPlanOptional.get());
        } catch (Exception e) {
            LOGGER.error(MESSAGE_FAIL_RETRIEVE_PLAN, e);
            return badRequestResponse(MESSAGE_FAIL_RETRIEVE_PLAN + " " +  MESSAGE_CHECK_LOGS);
        }
    }

    public T doGetPlans(String sourceProcessId, String targetProcessId) {
        try {
            List<MigrationPlan> migrationPlans = (List<MigrationPlan>) pimManagementService.findMigrationPlans(sourceProcessId, targetProcessId);
            return buildOkResponse("Retrieved process instance migration plans", migrationPlans);
        } catch (Exception e) {
            LOGGER.error(MESSAGE_FAIL_RETRIEVE_PLANS, e);
            return badRequestResponse(MESSAGE_FAIL_RETRIEVE_PLANS + " " +  MESSAGE_CHECK_LOGS);
        }
    }

    public T doDeletePlan(String planId) {
        try {
            pimManagementService.deletePlan(planId);
            return buildOkResponse("Deleted process instance migration plan.", planId);
        } catch (ProcessInstanceMigrationPlanNotFoundException nfe) {
            return notFoundResponse("Migration plan not found. id: '" + planId + "'");
        } catch (ProcessInstanceMigrationPlanInUseException iue) {
            return badRequestResponse("It's not possible to delete a plan that is being used.");
        } catch (Exception e) {
            LOGGER.error(MESSAGE_FAIL_DELETE_PLAN, e);
            return badRequestResponse(MESSAGE_FAIL_DELETE_PLAN +  " " + MESSAGE_CHECK_LOGS);
        }
    }

    public T doMigrateProcessInstance(ProcessInstanceMigrationSpec processInstanceMigrationSpec) {
        if (processInstanceMigrationSpec.getPlanId() == null || processInstanceMigrationSpec.getPlanId().isEmpty()) {
            return badRequestResponse("Missing required property: 'planId'");
        }

        if (processInstanceMigrationSpec.getProcessInstanceIds() != null && !processInstanceMigrationSpec.getProcessInstanceIds().isEmpty()) {
            return doMigrateProcessInstanceBatch(processInstanceMigrationSpec.getPlanId(), processInstanceMigrationSpec.getProcessInstanceIds());
        } else {
            return doMigrateAllProcessInstances(processInstanceMigrationSpec.getPlanId());
        }
    }

    private T doMigrateProcessInstanceBatch(String planId, Collection<String> processInstanceIds) {
        try {
            final String planIdEscapedForLogs = planId.replace('\n', '_').replace('\r', '_');

            LOGGER.info("Starting migration of {} process instances with plan: {}", processInstanceIds.size(), planIdEscapedForLogs);

            MigrationSummary summary = pimManagementService.migrateProcessInstances(processInstanceIds, planId);

            String responseMessage = format("Migration %s finished with Migration Plan '%s': %s Process instances migrated, %s Process Instances skipped", summary.getMigrationId(), planIdEscapedForLogs, summary.getMigratedProcessInstancesCount(), summary.getSkippedProcessInstanceIds());

            LOGGER.info(responseMessage);

            return buildOkResponse(responseMessage, summary);
        } catch (Exception e) {
            LOGGER.error("Failed to migrate {} process instances with plan '{}", processInstanceIds.size(), planId.replace('\n', '_').replace('\r', '_'), e);
            return badRequestResponse(MESSAGE_MIGRATION_FAILED + " " + MESSAGE_CHECK_LOGS);
        }
    }

    private T doMigrateAllProcessInstances(String planId) {
        try {
            final String planIdEscapedForLogs = planId.replace('\n', '_').replace('\r', '_');
            LOGGER.info("Starting process instance migration with plan: {}", planIdEscapedForLogs);

            MigrationSummary summary = pimManagementService.migrateAll(planId);

            String responseMessage = format("Migration %s finished with Migration Plan '%s': %s Process instances migrated", summary.getMigrationId(), planIdEscapedForLogs, summary.getMigratedProcessInstancesCount());

            LOGGER.info(responseMessage);

            return buildOkResponse(responseMessage, summary);
        } catch (Exception e) {
            LOGGER.error("Failed to migrate all process instances with plan '{}'. Error:", planId.replace('\n', '_').replace('\r', '_'), e);
            return badRequestResponse(MESSAGE_MIGRATION_FAILED + " " + MESSAGE_CHECK_LOGS);
        }
    }

    public T doGetMigratedProcessInstance(String processInstanceId) {
        try {
            Collection<ProcessInstanceMigration> migrations = pimManagementService.findMigrationsByProcessInstanceId(processInstanceId);

            if (migrations.isEmpty()) {
                return notFoundResponse("The process instance id '" + processInstanceId + "' doesn't have a linked migration plan");
            }

            return buildOkResponse("Retrieved migrated process instance", migrations);
        } catch (Exception e) {
            LOGGER.error("Failed to retrieve migrated process instance ({}). Error: ", processInstanceId.replace('\n', '_').replace('\r', '_'), e);
            return badRequestResponse(MESSAGE_FAIL_RETRIEVE_INSTANCE_AFTER_MIGRATION +  " " + MESSAGE_CHECK_LOGS);
        }
    }

    protected abstract T buildOkResponse(String message, Object data);

    protected abstract T buildCreatedResponse(String message, Object data);

    protected abstract T badRequestResponse(String message);

    protected abstract T badRequestResponse(String message, Object data);

    protected abstract T notFoundResponse(String message);

    private static ValidationResultResponse buildValidationResultResponseObject(ValidationResult result) {
        CategorizedReportedItemsResponse errors = (result.errors().processItems().isEmpty() && result.errors().nodeMappingItems().isEmpty())? null : new CategorizedReportedItemsResponse(
                result.errors().processItems().stream().map(it -> new ValidationResultReportedItemResponse<ProcessDescriptor>(it.validatedItem(), it.message())).toList(),
                result.errors().nodeMappingItems().stream().map(it -> new ValidationResultReportedItemResponse<NodeMapping>(it.validatedItem(), it.message())).toList());
        CategorizedReportedItemsResponse warnings = (result.warnings().processItems().isEmpty() && result.warnings().nodeMappingItems().isEmpty())? null : new CategorizedReportedItemsResponse(
                result.warnings().processItems().stream().map(it -> new ValidationResultReportedItemResponse<ProcessDescriptor>(it.validatedItem(), it.message())).toList(),
                result.warnings().nodeMappingItems().stream().map(it -> new ValidationResultReportedItemResponse<NodeMapping>(it.validatedItem(), it.message())).toList());
        return new ValidationResultResponse(result.result(), errors, warnings);
    }
}
