/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import com.ibm.bamoe.pim.api.model.ProcessInstanceMigration;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import org.kie.kogito.event.DataEvent;
import org.kie.kogito.event.EventPublisher;
import org.kie.kogito.event.process.ProcessInstanceStateDataEvent;
import org.kie.kogito.event.process.ProcessInstanceStateEventBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Date;
public class ProcessInstanceMigrationEventPublisher implements EventPublisher {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessInstanceMigrationEventPublisher.class);

    private ProcessInstanceMigrationsRepository migrationsRepository;

    public ProcessInstanceMigrationEventPublisher(ProcessInstanceMigrationsRepository migrationsRepository) {
        this.migrationsRepository = migrationsRepository;
    }

    @Override
    public void publish(DataEvent<?> event) {
        if(event.getType().equals("ProcessInstanceStateDataEvent")) {
            ProcessInstanceStateDataEvent  stateDataEvent = (ProcessInstanceStateDataEvent) event;
            if (stateDataEvent.getData().getEventType() == ProcessInstanceStateEventBody.EVENT_TYPE_ENDED) {
                handleProcessInstanceEndEvent(stateDataEvent);
            } else if (stateDataEvent.getData().getEventType() == ProcessInstanceStateEventBody.EVENT_TYPE_MIGRATED) {
                handleMigrateEvent(stateDataEvent);
            }
        }

    }

    private void handleProcessInstanceEndEvent(ProcessInstanceStateDataEvent event) {
        int deletedCount = migrationsRepository.deleteForProcessInstance(event.getKogitoProcessInstanceId());

        if(deletedCount > 0) {
            LOGGER.trace("Process Instance {} ({}) has been completed... deleted {} migrations", event.getKogitoProcessInstanceId(), event.getKogitoProcessId(), deletedCount);
        }
    }

    private void handleMigrateEvent(ProcessInstanceStateDataEvent event) {
        Collection<ProcessInstanceMigration> pendingMigrations = migrationsRepository.findUnappliedMigrationsByProcessInstanceId(event.getKogitoProcessInstanceId());

        if(pendingMigrations.isEmpty()) {
            LOGGER.trace("Migration event received for process instance {} ({}) but there are no pending migrations to delete in PIM repository. " +
                    "This usually means that the process instance has been loaded more than once during the migration process making the Workflow engine fire more than one migration event.", event.getKogitoProcessInstanceId(), event.getKogitoProcessId());
            return;
        }

        pendingMigrations.forEach(migration -> {
            migration.setAppliedAt(new Date());
            migrationsRepository.update(migration);
        });
    }

    @Override
    public void publish(Collection<DataEvent<?>> events) {
        for(DataEvent<?> event : events) {
            publish(event);
        }
    }
}
