/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.service;

import com.ibm.bamoe.pim.api.model.*;
import com.ibm.bamoe.pim.api.model.PlanSpec;
import com.ibm.bamoe.pim.migration.event.MigrationEventPublisher;
import com.ibm.bamoe.pim.migration.event.NewMigrationEvent;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import com.ibm.bamoe.pim.validation.PlanSpecValidator;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.Result;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.ValidationResult;

import org.kie.kogito.Model;
import org.kie.kogito.process.Process;
import org.kie.kogito.process.Processes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static java.util.UUID.randomUUID;

public class ProcessInstanceMigrationManagementServiceImpl implements ProcessInstanceMigrationManagementService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessInstanceMigrationManagementServiceImpl.class);

    private final ProcessInstanceMigrationManagementService.Configuration configuration;

    private final Processes processes;
    private final PlanSpecValidator planSpecValidator;

    private final ProcessInstanceMigrationPlanRepository plansRepository;
    private final ProcessInstanceMigrationsRepository migrationsRepository;

    private final MigrationEventPublisher migrationEventPublisher;

    public ProcessInstanceMigrationManagementServiceImpl(Processes processes, PlanSpecValidator planSpecValidator, ProcessInstanceMigrationPlanRepository plansRepository, ProcessInstanceMigrationsRepository pimMigrationsRepository, MigrationEventPublisher migrationEventPublisher, ProcessInstanceMigrationManagementService.Configuration configuration) {
        this.processes = processes;
        this.planSpecValidator = planSpecValidator;
        this.plansRepository = plansRepository;
        this.migrationsRepository = pimMigrationsRepository;
        this.migrationEventPublisher = migrationEventPublisher;
        this.configuration = Objects.requireNonNullElseGet(configuration, () -> new ProcessInstanceMigrationManagementService.Configuration() {});
    }

    @Override
    public ValidatedPlan createMigrationPlan(PlanSpec planSpec) {

        ValidationResult validationResult = planSpecValidator.validatePlan(planSpec);
        if (validationResult.result() == Result.FAILED) {
            return new ValidatedPlan(null, validationResult);
        }

        MigrationPlan migrationPlan = plansRepository.create(planSpec);

        return new ValidatedPlan(migrationPlan, validationResult);
    }

    @Override
    public Collection<MigrationPlan> findMigrationPlans(String sourceProcessId, String targetProcessId) {
        return plansRepository.findBySourceAndTarget(sourceProcessId, targetProcessId);
    }

    @Override
    public Optional<MigrationPlan> findMigrationPlanById(String planId) {
        return plansRepository.findById(planId);
    }

    @Override
    public void deletePlan(String planId) {
        Optional<MigrationPlan> MigrationPlanOptional = plansRepository.findById(planId);

        if(MigrationPlanOptional.isEmpty()) {
            throw new ProcessInstanceMigrationPlanNotFoundException();
        }

        if(migrationsRepository.existMigrationsForPlanId(planId)) {
            throw new ProcessInstanceMigrationPlanInUseException();
        }

        plansRepository.delete(planId);
    }

    @Override
    public MigrationSummary migrateProcessInstances(Collection<String> processInstanceIds, String planId) {

        String migrationId = randomUUID().toString();
        LOGGER.debug("Starting miration ({}) for {} process instances with migration plan {}", migrationId, processInstanceIds.size(), planId);

        if (processInstanceIds.size() > configuration.maxMigrationBulkSize()) {
            LOGGER.error("Couldn't start migration ({}) with plan {}: too many instances {}, please try to send a request with at most {}.", migrationId, planId, processInstanceIds.size(), configuration.maxMigrationBulkSize());
            throw new ProcessInstanceManagementException("Too many process instances in bulk %s, max number allowed is %s.".formatted(processInstanceIds.size(), configuration.maxMigrationBulkSize()));
        }

        Optional<MigrationPlan> planOptional = plansRepository.findById(planId);

        if (planOptional.isEmpty()) {
            LOGGER.error("Migration Plan with id not found: {}", planId);
            throw new ProcessInstanceManagementException("Plan not found. id: " + planId);
        }

        MigrationPlan migrationPlan = planOptional.get();

        Process<? extends Model> process = processes.processById(migrationPlan.getSourceProcessId());

        if(process == null) {
            LOGGER.error("Process not found. id: {}", migrationPlan.getSourceProcessId());
            throw new ProcessInstanceManagementException("Cannot find Process with id: " + migrationPlan.getSourceProcessId());
        }

        List<String> instanceIdsNotFound = processInstanceIds.stream()
                .filter(instanceId -> process.instances().findById(instanceId).isEmpty())
                .toList();

        if(!instanceIdsNotFound.isEmpty()) {
            LOGGER.warn("Skipping migration of {} instances: process instances {} not belong to proces '{}'", instanceIdsNotFound.size(), instanceIdsNotFound.toArray(), process.name());
            processInstanceIds.removeAll(instanceIdsNotFound);
        }

        if(processInstanceIds.isEmpty()) {
            LOGGER.error("No process instances found for plan {}", planId);
            throw new ProcessInstanceManagementException("No Process Instances found for plan: " + planId);
        }

        migrationsRepository.insertMigrations(migrationId, planId, migrationPlan.getSourceProcessId(), migrationPlan.getSourceProcessVersion(), processInstanceIds);

        process.instances().migrateProcessInstances(migrationPlan.getTargetProcessId(), migrationPlan.getTargetProcessVersion(), processInstanceIds.toArray(new String[0]));

        migrationEventPublisher.onNewMigration(new NewMigrationEvent(migrationId, migrationPlan));

        return new MigrationSummary(migrationId, planId, processInstanceIds.size(), instanceIdsNotFound);
    }

    @Override
    public MigrationSummary migrateAll(String planId) {
        String migrationId = randomUUID().toString();

        LOGGER.debug("Starting full miration ({}) for migration plan {}", migrationId, planId);
        Optional<MigrationPlan> planOptional = plansRepository.findById(planId);

        if (planOptional.isEmpty()) {
            LOGGER.error("Aborting migration ({}) for migration plan {}: Plan cannot be found", migrationId, planId);
            throw new ProcessInstanceManagementException("Plan not found. id: " + planId);
        }

        MigrationPlan migrationPlan = planOptional.get();

        long migrationStartTime = System.currentTimeMillis();

        long totalMigrated = migrationsRepository.insertMigrations(migrationId, planId, migrationPlan.getSourceProcessId(), migrationPlan.getSourceProcessVersion());

        processes.processById(migrationPlan.getSourceProcessId())
                .instances()
                .migrateAll(migrationPlan.getTargetProcessId(), migrationPlan.getTargetProcessVersion());

        LOGGER.debug("Successfully migrated {} process instances after {}ms", totalMigrated,  System.currentTimeMillis() - migrationStartTime);

        migrationEventPublisher.onNewMigration(new NewMigrationEvent(migrationId, migrationPlan));

        return new MigrationSummary(migrationId, planId, totalMigrated);
    }

    @Override
    public Collection<ProcessInstanceMigration> findMigrationsByProcessInstanceId(String processInstanceId) {
        return migrationsRepository.findMigrationsByProcessInstanceId(processInstanceId);
    }

}
