/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import java.util.concurrent.atomic.AtomicReference;

public class ProcessInstanceMigrationServiceHolder {
    private static final AtomicReference<ProcessInstanceMigrationExecutor> service = new AtomicReference<>();

    public static void setService(ProcessInstanceMigrationExecutor newService) {
        service.set(newService);
    }

    public static ProcessInstanceMigrationExecutor getService() {
        return service.get();
    }
}
