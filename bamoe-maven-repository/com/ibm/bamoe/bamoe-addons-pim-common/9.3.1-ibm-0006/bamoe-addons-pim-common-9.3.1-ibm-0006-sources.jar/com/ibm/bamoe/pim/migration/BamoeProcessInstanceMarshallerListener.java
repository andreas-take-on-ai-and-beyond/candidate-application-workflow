/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import org.jbpm.flow.serialization.ProcessInstanceMarshallerListener;
import org.kie.kogito.internal.process.runtime.KogitoNodeInstance;
import org.kie.kogito.internal.process.runtime.KogitoProcessRuntime;
import org.kie.kogito.internal.process.runtime.KogitoWorkflowProcessInstance;
import org.kie.kogito.process.Processes;

public class BamoeProcessInstanceMarshallerListener implements ProcessInstanceMarshallerListener {
    private ProcessInstanceMigrationExecutor pimService;

    private ProcessInstanceMigrationExecutor getService() {
        if (pimService == null) {
            pimService = ProcessInstanceMigrationServiceHolder.getService();
            if (pimService == null) {
                throw new IllegalStateException("Migration service not initialized. Ensure CDI bootstrap is working.");
            }
        }
        return pimService;
    }

    @SuppressWarnings("deprecation")
    @Override
    public void afterUnmarshallProcess(KogitoProcessRuntime runtime, KogitoWorkflowProcessInstance processInstance) {
         getService().migrateProcessElement(runtime, processInstance);
    }

    @Override
    public void afterUnmarshallNode(KogitoProcessRuntime runtime, KogitoNodeInstance nodeInstance) {
        getService().migrateNodeElement(runtime.getApplication().get(Processes.class), nodeInstance);
    }
}
