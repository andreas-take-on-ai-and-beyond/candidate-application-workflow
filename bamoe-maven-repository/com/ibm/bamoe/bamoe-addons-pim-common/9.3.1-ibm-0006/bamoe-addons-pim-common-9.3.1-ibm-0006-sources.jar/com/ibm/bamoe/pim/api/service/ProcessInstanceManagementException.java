/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.service;

import java.io.IOException;

public class ProcessInstanceManagementException extends RuntimeException{
    public ProcessInstanceManagementException(String message) {
        super(message);
    }

    public ProcessInstanceManagementException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
