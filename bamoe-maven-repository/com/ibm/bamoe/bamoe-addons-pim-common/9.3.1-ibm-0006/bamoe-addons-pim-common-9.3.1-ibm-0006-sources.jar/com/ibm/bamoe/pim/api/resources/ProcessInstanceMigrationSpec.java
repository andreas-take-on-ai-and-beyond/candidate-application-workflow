/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Collection;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ProcessInstanceMigrationSpec {
    
    private String planId;
    private Collection<String> processInstanceIds;
    
    public ProcessInstanceMigrationSpec() {
    }

    public ProcessInstanceMigrationSpec(String planId) {
        this.planId = planId;
    }

    public ProcessInstanceMigrationSpec(String planId, Collection<String> processInstanceIds) {
        this.planId = planId;
        this.processInstanceIds = processInstanceIds;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public Collection<String> getProcessInstanceIds() {
        return processInstanceIds;
    }

    public void setProcessInstanceIds(Collection<String> processInstanceIds) {
        this.processInstanceIds = processInstanceIds;
    }
}
