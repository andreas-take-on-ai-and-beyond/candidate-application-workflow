/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.model.PlanSpec;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.ProcessDescriptor;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.Result;

public interface ProcessInstanceMigrationResourceInterface<T> {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public record ValidatedPlanResponse(MigrationPlan plan, ValidationResultResponse validation) {
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public record ValidationResultReportedItemResponse<T>(@JsonUnwrapped T validatedItem, String message) {
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public record CategorizedReportedItemsResponse(List<ValidationResultReportedItemResponse<ProcessDescriptor>> processes, List<ValidationResultReportedItemResponse<NodeMapping>> nodeMappings) {
    }

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public record ValidationResultResponse(Result result, CategorizedReportedItemsResponse errors, CategorizedReportedItemsResponse warnings) {
    }

    T createPlan(PlanSpec planSpec);
    T getPlan(String planId);
    T getPlans(String sourceProcessId, String targetProcessId);
    T deletePlan(String planId);

    T migrateProcessInstance(ProcessInstanceMigrationSpec processInstanceMigrationSpec);
    T getMigratedProcessInstances(String processInstanceId);
}
