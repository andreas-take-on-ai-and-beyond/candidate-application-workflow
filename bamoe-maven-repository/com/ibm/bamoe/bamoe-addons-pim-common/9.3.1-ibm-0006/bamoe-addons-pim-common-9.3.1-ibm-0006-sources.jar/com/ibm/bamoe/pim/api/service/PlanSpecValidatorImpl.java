/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
// Assisted by watsonx Code Assistant
package com.ibm.bamoe.pim.api.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.kie.kogito.Model;
import org.kie.kogito.internal.process.runtime.KogitoNode;
import org.kie.kogito.process.Process;
import org.kie.kogito.process.Processes;

import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.model.PlanSpec;
import com.ibm.bamoe.pim.api.service.NodeMappingValidator.Type;
import com.ibm.bamoe.pim.validation.PlanSpecValidator;

public class PlanSpecValidatorImpl implements PlanSpecValidator {

    private final Processes processes;

    public PlanSpecValidatorImpl(Processes processes) {
        this.processes = processes;
    }

    @Override
    public ValidationResult validatePlan(PlanSpec spec) {
        return validatePlan(spec, null);
    }

    @Override
    public ValidationResult validatePlan(PlanSpec spec, Level failureThresholdLevel) {
        PlanSpecValidationTracker validationTracker = new PlanSpecValidationTracker();
        if (failureThresholdLevel != null) {
            validationTracker.setFailureThreshold(failureThresholdLevel);
        }
        Optional<Process<? extends Model>> maybeSourceProcess = validateProcessByIdAndVersion(validationTracker, spec.getSourceProcessId(), spec.getSourceProcessVersion());
        Optional<Process<? extends Model>> maybeTargetProcess = validateProcessByIdAndVersion(validationTracker, spec.getTargetProcessId(), spec.getTargetProcessVersion());
        if (maybeSourceProcess.isPresent() && maybeTargetProcess.isPresent()) {
            var sourceProcess = maybeSourceProcess.get();
            var targetProcess = maybeTargetProcess.get();
            if (Objects.equals(sourceProcess.id(), targetProcess.id()) && Objects.equals(sourceProcess.version(), targetProcess.version())) {
                validationTracker.reportError(new ProcessDescriptor(sourceProcess.id(), sourceProcess.version()), PlanSpecValidationTracker.sourceAndTargetProcessesAreTheSame(sourceProcess.id(), sourceProcess.version()));
            }
            Map<String, KogitoNode> sourceNodes = sourceProcess.findNodes(it -> true).stream().collect(Collectors.toMap(PlanSpecValidatorImpl::getKogitoNodeId, it -> it));
            Map<String, KogitoNode> targetNodes = targetProcess.findNodes(it -> true).stream().collect(Collectors.toMap(PlanSpecValidatorImpl::getKogitoNodeId, it -> it));

            // Container to hold node mappings either provided explicitly, or implicit mappings based on id match.
            List<NodeMapping> applicableNodeMappings = new ArrayList<>();

            if (spec.getNodeMapping() != null && !spec.getNodeMapping().isEmpty()) {
                applicableNodeMappings.addAll(spec.getNodeMapping());
            } else {
                sourceNodes.entrySet().stream().filter(e->Type.of(e.getValue()).isSafePoint()).forEach(e -> {
                    String sourceNodeId = e.getKey();
                    applicableNodeMappings.add(new NodeMapping(sourceNodeId, sourceNodeId));
                });
            }
            validateSourceNodeIds(validationTracker, spec.getSourceProcessId(), applicableNodeMappings, sourceNodes);
            validateTargetNodeIds(validationTracker, spec.getTargetProcessId(), applicableNodeMappings, targetNodes);

            sourceNodes.values().stream().filter(Type::isSafePoint)
                    .filter(it -> applicableNodeMappings.stream().noneMatch(m -> m.getSourceId().equals(getKogitoNodeId(it))))
                    .forEach(it -> validationTracker.reportError(
                            new NodeMapping(getKogitoNodeId(it), getKogitoNodeId(it)),
                            PlanSpecValidationTracker.nodeMappingForSourceNodeIsMissing(it, sourceProcess.id())));

            NodeMappingValidator.builder()
                    .withSourceNodes(sourceNodes)
                    .withTargetNodes(targetNodes)
                    .withRestriction()
                        .withSeverityLevel(Level.ERROR)
                        .withDescription(PlanSpecValidationTracker::nodeMappingTypeMismatch)
                        .withSourceNodeFilter(from -> !Type.CATCH_EVENTS_MAPPINGS_FAMILY.contains(Type.of(from)))
                        .withMappingRule((from, to) -> Type.of(from) == Type.of(to))
                        .build()
                    .withRestriction()
                        .withSeverityLevel(Level.ERROR)
                        .withDescription((from, to) -> PlanSpecValidationTracker.nodeMappingTypeFamilyMismatch(from, to, Type.CATCH_EVENTS_MAPPINGS_FAMILY))
                        .withSourceNodeFilter(from -> Type.CATCH_EVENTS_MAPPINGS_FAMILY.contains(Type.of(from)))
                        .withMappingRule((from, to) -> Type.CATCH_EVENTS_MAPPINGS_FAMILY.contains(Type.of(to)))
                        .build()
                    .withRestriction()
                        .withSeverityLevel(Level.ERROR)
                        .withDescription(PlanSpecValidationTracker::nodeMappingSourceNodeUnexpectedType)
                        .withMappingRule((from, to) -> Type.of(from).isSafePoint())
                        .build()
                    .withRestriction()
                        .withSeverityLevel(Level.WARNING)
                        .withDescription(PlanSpecValidationTracker::nodeMappingNodeIdEqualsButOtherFieldDiffer)
                        .withMappingRule((from, to) -> !from.getId().equals(to.getId()) || kogitoNodesEqual(from, to)) // nodes with matching ids can't have any other change.
                        .build()
                    .build()
                    .validateNodeMappings(applicableNodeMappings, validationTracker);
        }
        return validationTracker.evaluate();
    }

    /**
     * Method to check if KogitoNode instances are equal with regards to PIM limitations.
     * 
     * @param fst first instance to compare
     * @param snd second instance to compare
     * @return true if nodes are considered equal
     */
    public boolean kogitoNodesEqual(KogitoNode fst, KogitoNode snd) {
        return Objects.equals(fst.getId(), snd.getId())
                && Objects.equals(fst.getName(), snd.getName())
                && Objects.equals(fst.getUniqueId(), snd.getUniqueId());
    }

    /**
     * Validates a process by its ID and version.
     *
     * @param validationTracker tracker to report problems into
     * @param inputProcessId The ID of the process to validate.
     * @param inputProcessVersion The version of the process to validate.
     * @return An Optional containing the process if it exists and matches the version, otherwise an empty Optional.
     * @throws IllegalArgumentException if the inputProcessId is null or empty.
     */
    private Optional<Process<? extends Model>> validateProcessByIdAndVersion(PlanSpecValidationTracker validationTracker, String inputProcessId, String inputProcessVersion) {
        // Validate inputProcessId
        if (inputProcessId == null || inputProcessId.isEmpty()) {
            throw new IllegalArgumentException("Input process ID cannot be null or empty.");
        }

        Process<? extends Model> processById = processes.processById(inputProcessId);
        if (processById == null) {
            validationTracker.reportError(new ProcessDescriptor(inputProcessId, inputProcessVersion), PlanSpecValidationTracker.processWithGivenIdDoesNotExist(inputProcessId));
        } else {
            // org.kie.kogito.process.Process#processById doesn't seem to account for multiple versions of a single process id, so only checking the one retrieved above.
            if (!processById.version().equals(inputProcessVersion)) {
                validationTracker.reportError(new ProcessDescriptor(inputProcessId, inputProcessVersion),
                        PlanSpecValidationTracker.processWithGivenIdHasDifferentVersion(inputProcessId, inputProcessVersion, processById.version()));
            }
        }
        return Optional.ofNullable(processById);
    }

    /**
     * Validates source node IDs in the given PlanSpec against the provided nodes map.
     *
     * @param validationTracker tracker to report problems into
     * @param processId         The process Id
     * @param nodeMappings      mappings to validate
     * @param nodes             A map of node IDs to KogitoNode objects.
     * @throws IllegalArgumentException if the input parameters are null.
     */
    private void validateSourceNodeIds(PlanSpecValidationTracker validationTracker, String processId, List<NodeMapping> nodeMappings, Map<String, KogitoNode> nodes) {
        if (processId == null || processId.isEmpty() || nodes == null) {
            throw new IllegalArgumentException("Input parameters cannot be null.");
        }

        if (nodeMappings == null || nodeMappings.isEmpty()) {
            return;
        }
        List<String> idsToSearch = nodeMappings.stream()
                .map(NodeMapping::getSourceId)
                .toList();

        // Set to track duplicate source node IDs
        Set<String> duplicatesCheckSet = new HashSet<>();
        Set<String> duplicates = nodeMappings.stream()
                .map(NodeMapping::getSourceId).filter(sourceId -> !duplicatesCheckSet.add(sourceId)).collect(Collectors.toSet());
        duplicates.stream().flatMap(it -> nodeMappings.stream().filter(m -> m.getSourceId().equals(it)))
                .forEach(it -> validationTracker.reportError(it, PlanSpecValidationTracker.nodeMappingSourceNodeMultipleMappings(nodes.get(it.getSourceId()).getName())));

        // Set of source node IDs found in the nodes map
        Set<String> idsFound = nodes.keySet().stream()
                .filter(idsToSearch::contains)
                .collect(Collectors.toSet());

        // Report errors for source node IDs found in PlanSpec but not in the nodes map
        nodeMappings.stream()
                .filter(mapping -> !idsFound.contains(mapping.getSourceId()))
                .forEach(mapping -> validationTracker.reportError(mapping, PlanSpecValidationTracker.nodeMappingSourceNodeProblem(mapping.getSourceId(), processId)));
    }

    /**
     * Validates the target node IDs in the given plan specification against the provided nodes map.
     *
     * @param validationTracker tracker object to report problems into
     * @param processId         id of the process
     * @param nodeMappings      list of NodeMapping objects
     * @param nodes             The map of Kogito nodes.
     * @throws IllegalArgumentException if the input parameters are null.
     */
    private void validateTargetNodeIds(PlanSpecValidationTracker validationTracker, String processId, List<NodeMapping> nodeMappings, Map<String, KogitoNode> nodes) {
        if (processId == null || processId.isEmpty() || nodes == null) {
            throw new IllegalArgumentException("Input parameters cannot be null.");
        }
        if (nodeMappings == null || nodeMappings.isEmpty()) {
            return;
        }
        List<String> idsToSearch = nodeMappings
                .stream()
                .map(NodeMapping::getTargetId)
                .toList();

        // Find node IDs in the nodes map that match the target node IDs from the specification
        Set<String> idsFound = nodes.keySet().stream()
                .filter(idsToSearch::contains)
                .collect(Collectors.toSet());

        // Report errors for any target node IDs not found in the nodes map
        nodeMappings.stream()
                .filter(mapping -> !idsFound.contains(mapping.getTargetId()))
                .forEach(mapping -> validationTracker.reportError(mapping,
                        PlanSpecValidationTracker.nodeMappingTargetNodeProblem(mapping.getTargetId(), processId)));
    }

    static String getKogitoNodeId(KogitoNode node) {
        return node.getId().toExternalFormat();
    }

    public static class PlanSpecValidationTracker {

        private Level failureThreshold = Level.ERROR;
        private final List<ValidationResultReportedItem<ProcessDescriptor>> processErrors = new ArrayList<>();
        private final List<ValidationResultReportedItem<ProcessDescriptor>> processWarnings = new ArrayList<>();
        private final List<ValidationResultReportedItem<NodeMapping>> nodeMappingsErrors = new ArrayList<>();
        private final List<ValidationResultReportedItem<NodeMapping>> nodeMappingsWarnings = new ArrayList<>();

        public void setFailureThreshold(Level failureThreshold) {
            this.failureThreshold = failureThreshold;
        }


        public void reportAtLevel(ProcessDescriptor process, String message, Level level) {
            switch (level) {
                case ERROR:
                    reportError(process, message);
                    break;
                case WARNING:
                    reportWarning(process, message);
                    break;
            }
        }

        public void reportAtLevel(NodeMapping nodeMapping, String message, Level level) {
            switch (level) {
                case ERROR:
                    reportError(nodeMapping, message);
                    break;
                case WARNING:
                    reportWarning(nodeMapping, message);
                    break;
            }
        }

        public void reportError(ProcessDescriptor validatedItem, String message) {
            processErrors.add(new ValidationResultReportedItem<ProcessDescriptor>(validatedItem, Level.ERROR, message));
        }

        public void reportError(NodeMapping validatedItem, String message) {
            nodeMappingsErrors.add(new ValidationResultReportedItem<NodeMapping>(validatedItem, Level.ERROR, message));
        }

        public void reportWarning(ProcessDescriptor validatedItem, String message) {
            processWarnings.add(new ValidationResultReportedItem<ProcessDescriptor>(validatedItem, Level.WARNING, message));
        }

        public void reportWarning(NodeMapping validatedItem, String message) {
            nodeMappingsWarnings.add(new ValidationResultReportedItem<NodeMapping>(validatedItem, Level.WARNING, message));
        }

        public ValidationResult evaluate() {
            return new ValidationResult(failureThreshold, !listReasonsForFailure().isEmpty() ? Result.FAILED : Result.PASSED, new CategorizedReportedItems(processErrors, nodeMappingsErrors), new CategorizedReportedItems(processWarnings, nodeMappingsWarnings));
        }

        public List<ValidationResultReportedItem<?>> listReasonsForFailure() {
            return listAllProblems().stream().filter(it -> it.level().ordinal() >= failureThreshold.ordinal()).collect(Collectors.toList());
        }

        public List<ValidationResultReportedItem<ProcessDescriptor>> listProcessDefinitionsErrors() {
            return this.processErrors;
        }

        public List<ValidationResultReportedItem<ProcessDescriptor>> listProcessDefinitionsWarnings() {
            return this.processWarnings;
        }

        public List<ValidationResultReportedItem<NodeMapping>> listNodeMappingsErrors() {
            return this.nodeMappingsErrors;
        }

        public List<ValidationResultReportedItem<NodeMapping>> listNodeMappingsWarnings() {
            return this.nodeMappingsWarnings;
        }

        public List<ValidationResultReportedItem<?>> listAllProblems() {
            List<ValidationResultReportedItem<?>> allReports = new ArrayList<>();
            allReports.addAll(this.processErrors);
            allReports.addAll(this.processWarnings);
            allReports.addAll(this.nodeMappingsErrors);
            allReports.addAll(this.nodeMappingsWarnings);
            return allReports;
        }

        public static String nodeMappingSourceNodeProblem(String nodeId, String processId) {
            return String.format("Node mapping source node with id '%s' does not exist in process with id '%s'.", nodeId, processId);
        }

        public static String nodeMappingTargetNodeProblem(String nodeId, String processId) {
            return String.format("Node mapping target node with id '%s' does not exist in process with id '%s'.", nodeId, processId);
        }

        public static String nodeMappingSourceNodeMultipleMappings(String nodeName) {
            return String.format("Node mapping source node '%s' has multiple mappings.", nodeName);
        }

        public static String nodeMappingForSourceNodeIsMissing(KogitoNode node, String sourceProcessId) {
            return String.format("Node mapping for source node '%s' from process with id '%s' is missing.", getKogitoNodeMessageReference(node), sourceProcessId);
        }

        public static String processWithGivenIdDoesNotExist(String processId) {
            return String.format("Couldn't find process id '%s' among available processes.", processId);
        }

        public static String processWithGivenIdHasDifferentVersion(String mappingProcessId, String mappingProcessVersion, String foundProcessVersion) {
            return String.format("Process with id '%s' has different version. Searched for: '%s'. Found: '%s'.", mappingProcessId, mappingProcessVersion, foundProcessVersion);
        }

        public static String sourceAndTargetProcessesAreTheSame(String processId, String processVersion) {
            return String.format("Source and target process ids are identical (id: '%s', version: '%s')", processId, processVersion);
        }

        public static String nodeMappingTypeMismatch(KogitoNode sourceNode, KogitoNode targetNode) {
            return String.format("Mapped node types mismatch: %s -> %s.", getKogitoNodeMessageReference(sourceNode), getKogitoNodeMessageReference(targetNode));
        }

        public static String nodeMappingTypeFamilyMismatch(KogitoNode sourceNode, KogitoNode targetNode, Set<Type> family) {
            return String.format("Mapped node type family mismatch: %s -> %s. Mapped nodes should both be one of: %s", getKogitoNodeMessageReference(sourceNode), getKogitoNodeMessageReference(targetNode), family.stream().map(it -> "'%s'".formatted(it.getTypeName())).collect(Collectors.joining(", ")));
        }

        public static String nodeMappingSourceNodeUnexpectedType(KogitoNode sourceNode, KogitoNode targetNode) {
            return String.format("Wrong node mapping in '%s' -> '%s'. Mapped nodes should be one of: %s.", getKogitoNodeMessageReference(sourceNode), getKogitoNodeMessageReference(targetNode), Type.SAFE_POINTS.stream().map(it -> "'%s'".formatted(it.getTypeName())).collect(Collectors.joining(", ")));
        }

        public static String nodeMappingNodeIdEqualsButOtherFieldDiffer(KogitoNode sourceNode, KogitoNode targetNode) {
            return String.format("Node id equals for mapped nodes, but other fields differ: %s -> %s.", getKogitoNodeMessageReference(sourceNode), getKogitoNodeMessageReference(targetNode));
        }

        public static String getKogitoNodeMessageReference(KogitoNode node) {
            return String.format("(name:'%s', id:'%s', type:'%s')", node.getName(), getKogitoNodeId(node), Type.of(node).getTypeName());
        }
    }

}
