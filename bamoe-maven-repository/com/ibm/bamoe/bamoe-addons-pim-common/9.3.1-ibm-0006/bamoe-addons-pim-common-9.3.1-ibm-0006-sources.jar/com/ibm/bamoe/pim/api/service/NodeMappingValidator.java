/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.service;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import org.jbpm.ruleflow.core.Metadata;
import org.jbpm.workflow.core.node.SubProcessNode;
import org.kie.api.definition.process.NodeType;
import org.kie.kogito.internal.process.runtime.KogitoNode;

import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.service.PlanSpecValidatorImpl.PlanSpecValidationTracker;
import com.ibm.bamoe.pim.validation.PlanSpecValidator.Level;

class NodeMappingValidator {
    private List<NodeMappingRestriction> restrictions = new ArrayList<>();
    private Map<String, KogitoNode> sourceNodes;
    private Map<String, KogitoNode> targetNodes;

    private NodeMappingValidator() {
    }

    public static NodeMappingValidator.Builder builder() {
        return new NodeMappingValidator.Builder();
    }

    public void validateNodeMappings(List<NodeMapping> nodeMappings, PlanSpecValidationTracker validationTracker) {
        nodeMappings.forEach(mapping -> {
            String sourceNodeId = mapping.getSourceId();
            String targetNodeId = mapping.getTargetId();
            KogitoNode sourceNode = sourceNodes.get(sourceNodeId);
            KogitoNode targetNode = targetNodes.get(targetNodeId);
            if (sourceNode != null && targetNode != null) {
                restrictions.stream().filter(it -> it.sourceNodesFilter.test(sourceNode) && !it.allowedTargetNodesFilter.test(sourceNode, targetNode))
                        .forEach(it -> validationTracker.reportAtLevel(mapping, it.descriptionFormatter.apply(sourceNode, targetNode), it.severityLevel()));
            }
        });
    }

    static class Builder {
        private final List<NodeMappingRestriction> restrictions = new ArrayList<>();
        private Map<String, KogitoNode> sourceNodes;
        private Map<String, KogitoNode> targetNodes;

        private Builder() {}

        public RestrictionBuilder withRestriction() {
            return new RestrictionBuilder(this);
        }

        public NodeMappingValidator.Builder withSourceNodes(Map<String, KogitoNode> sourceNodes) {
            this.sourceNodes = sourceNodes;
            return this;
        }

        public NodeMappingValidator.Builder withTargetNodes(Map<String, KogitoNode> targetNodes) {
            this.targetNodes = targetNodes;
            return this;
        }

        public NodeMappingValidator build() {
            NodeMappingValidator instance = new NodeMappingValidator();
            instance.restrictions = List.copyOf(this.restrictions);
            instance.sourceNodes = Map.copyOf(sourceNodes);
            instance.targetNodes = Map.copyOf(targetNodes);
            return instance;
        }
    }

    public record NodeMappingRestriction(Level severityLevel, BiFunction<KogitoNode, KogitoNode, String> descriptionFormatter, Predicate<KogitoNode> sourceNodesFilter, BiPredicate<KogitoNode, KogitoNode> allowedTargetNodesFilter) {}

    public static class RestrictionBuilder {
        private final NodeMappingValidator.Builder parentBuilder;
        private Level severityLevel;
        private BiFunction<KogitoNode, KogitoNode, String> descriptionSupplier;
        private final List<Predicate<KogitoNode>> sourceNodesFilters = new ArrayList<>();
        private final List<BiPredicate<KogitoNode, KogitoNode>> mappingRules = new ArrayList<>();

        RestrictionBuilder(NodeMappingValidator.Builder parentBuilder) {
            this.parentBuilder = parentBuilder;
        }

        RestrictionBuilder withDescription(BiFunction<KogitoNode, KogitoNode, String> descriptionFormatter) {
            this.descriptionSupplier = descriptionFormatter;
            return this;
        }

        RestrictionBuilder withSourceNodeFilter(Predicate<KogitoNode> sourceNodeFilter) {
            this.sourceNodesFilters.add(sourceNodeFilter);
            return this;
        }

        RestrictionBuilder withMappingRule(BiPredicate<KogitoNode, KogitoNode> mappingRule) {
            this.mappingRules.add(mappingRule);
            return this;
        }

        RestrictionBuilder withSeverityLevel(Level level) {
            this.severityLevel = level;
            return this;
        }

        NodeMappingValidator.Builder build() {
            parentBuilder.restrictions.add(new NodeMappingRestriction(severityLevel, descriptionSupplier, n -> sourceNodesFilters.stream().allMatch(it -> it.test(n)),
                    (n1, n2) -> mappingRules.stream().allMatch(it -> it.test(n1, n2))));
            return parentBuilder;
        }
    }


    public List<NodeMappingRestriction> getRestrictions() {
        return restrictions;
    }

    public void setRestrictions(List<NodeMappingRestriction> restrictions) {
        this.restrictions = restrictions;
    }

    public enum Type {
        CATCH_EVENT_MESSAGE("Message Catch Event", kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_MESSAGE.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_SIGNAL("Signal Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_SIGNAL.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_LINK("Link Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_LINK.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_ERROR("Error Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_ERROR.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_ESCALATION("Escalation Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_ESCALATION.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_COMPENSATION("Compensation Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_COMPENSATION.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        CATCH_EVENT_CONDITIONAL("Conditional Catch Event",  kogitoNode -> kogitoNode.getNodeType() == NodeType.CATCH_EVENT && Metadata.EVENT_TYPE_CONDITIONAL.equals(kogitoNode.getMetaData().get(Metadata.EVENT_TYPE))),
        SUBPROCESS("Call Activity", kogitoNode -> kogitoNode.getNodeType() == NodeType.SUBPROCESS && ((SubProcessNode)kogitoNode).isWaitForCompletion()),
        TIMER_EVENT("Timer Event", kogitoNode -> kogitoNode.getNodeType() == NodeType.TIMER),
        USER_TASK("User Task", kogitoNode -> kogitoNode.getNodeType() == NodeType.HUMAN_TASK),
        WORK_ITEM("Work Item", kogitoNode -> kogitoNode.getNodeType() == NodeType.WORKITEM_TASK),
        DEFAULT("Default", kogitoNode -> false);

        public static final Set<Type> SAFE_POINTS = Set.of(CATCH_EVENT_MESSAGE, CATCH_EVENT_SIGNAL, TIMER_EVENT, CATCH_EVENT_LINK, CATCH_EVENT_ERROR,
                CATCH_EVENT_ESCALATION, CATCH_EVENT_COMPENSATION, CATCH_EVENT_CONDITIONAL, SUBPROCESS, USER_TASK, WORK_ITEM);
        public static final Set<Type> CATCH_EVENTS_MAPPINGS_FAMILY = Set.of(CATCH_EVENT_MESSAGE, CATCH_EVENT_SIGNAL, CATCH_EVENT_LINK, CATCH_EVENT_ERROR,
                CATCH_EVENT_ESCALATION, CATCH_EVENT_COMPENSATION, CATCH_EVENT_CONDITIONAL);

        private final String typeName;
        private final Predicate<KogitoNode> nodeTypeChecker;

        Type(String typeName, Predicate<KogitoNode> nodeTypeChecker) {
            this.nodeTypeChecker = nodeTypeChecker;
            this.typeName = typeName;
        }

        public String getTypeName() {
            return typeName;
        }

        public boolean isSafePoint() {
            return SAFE_POINTS.contains(this);
        }

        public static Type of(KogitoNode node) {
            return SAFE_POINTS.stream().filter(it -> it.nodeTypeChecker.test(node)).findFirst().orElse(Type.DEFAULT);
        }

        public static boolean isSafePoint(Type t) {
            return SAFE_POINTS.contains(t);
        }

        public static boolean isSafePoint(KogitoNode kogitoNode) {
            return isSafePoint(Type.of(kogitoNode));
        }
    }
}
