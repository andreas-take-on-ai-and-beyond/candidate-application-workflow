/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;


import com.ibm.bamoe.pim.api.model.MigrationPlan;

import java.util.Date;

public class PlanValidationResult {
    private final MigrationPlan plan;
    private final boolean valid;
    private final String reason;
    private final Date appliedAt;

    public PlanValidationResult(MigrationPlan plan, boolean valid, Date appliedAt, String reason) {
        this.plan = plan;
        this.valid = valid;
        this.reason = reason;
        this.appliedAt = appliedAt;
    }

    public MigrationPlan getPlan() {
        return plan;
    }

    public boolean isValid() {
        return valid;
    }

    public String getReason() {
        return reason;
    }

    public Date getAppliedAt() {
        return appliedAt;
    }
}
