/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.api.resources;

import java.time.Instant;

public class SuccessResponse {
    private Instant timestamp;
    private int status;
    private String message;
    private Object data;

    public SuccessResponse() {
        this.timestamp = Instant.now();
    }

    public SuccessResponse(String message, int status, Object data) {
        this();
        this.message = message;
        this.status = status;
        this.data = data;
    }

    public Instant getTimestamp() {
      return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
      this.timestamp = timestamp;
    }

    public int getStatus() {
      return status;
    }

    public void setStatus(int status) {
      this.status = status;
    }

    public String getMessage() {
      return message;
    }

    public void setMessage(String message) {
      this.message = message;
    }

    public Object getData() {
      return data;
    }

    public void setData(Object data) {
      this.data = data;
    }

    
}

