/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.migration;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.api.model.NodeMapping;
import com.ibm.bamoe.pim.api.model.ProcessInstanceMigration;
import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationPlanRepository;
import org.jbpm.ruleflow.core.WorkflowElementIdentifierFactory;
import org.jbpm.ruleflow.instance.RuleFlowProcessInstance;
import org.jbpm.workflow.instance.impl.NodeInstanceImpl;
import org.kie.api.definition.process.Process;
import org.kie.api.definition.process.WorkflowElementIdentifier;
import org.kie.kogito.internal.process.runtime.KogitoNodeInstance;
import org.kie.kogito.internal.process.runtime.KogitoProcessRuntime;
import org.kie.kogito.internal.process.runtime.KogitoWorkflowProcessInstance;
import org.kie.kogito.process.Processes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.bamoe.pim.persistence.ProcessInstanceMigrationsRepository;

public class ProcessInstanceMigrationExecutor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessInstanceMigrationExecutor.class);

    private ProcessInstanceMigrationsRepository pimRepository;
    private ProcessInstanceMigrationPlanRepository processInstanceMigrationPlanRepository;

    public ProcessInstanceMigrationExecutor(ProcessInstanceMigrationsRepository pimRepository, ProcessInstanceMigrationPlanRepository processInstanceMigrationPlanRepository) {
        this.pimRepository = pimRepository;
        this.processInstanceMigrationPlanRepository = processInstanceMigrationPlanRepository;
    }

    public void migrateProcessElement(KogitoProcessRuntime runtime, KogitoWorkflowProcessInstance processInstance) {

        if (!processInstanceRequiresMigration(processInstance)) {
            LOGGER.trace("Skipping migration: Process instance doesn't require migration.");
            return;
        }

        Collection<ProcessInstanceMigration> migrationStack = pimRepository.findUnappliedMigrationsByProcessInstanceId(processInstance.getId());

        if (migrationStack.isEmpty()) {
            LOGGER.debug("Skipping migration for Process Instance '{}': No migrations found",  processInstance.getId());
            return;
        }

        LOGGER.debug("Migrating process instance ({}) from {}@{} to {}@{} ({} migration/s pending)",
                processInstance.getId(),
                processInstance.getProcessId(),
                processInstance.getProcessVersion(),
                processInstance.getProcess().getId(),
                processInstance.getProcess().getVersion(),
                migrationStack.size());

        RuleFlowProcessInstance ruleFlowProcessInstance = (RuleFlowProcessInstance) processInstance;
        ruleFlowProcessInstance.setProcessId(processInstance.getProcess().getId());
        ruleFlowProcessInstance.setProcessVersion(processInstance.getProcess().getVersion());

        runtime.getProcessEventSupport().fireOnMigration(processInstance, runtime.getKieRuntime());
    }

    public void migrateNodeElement(Processes processes, KogitoNodeInstance nodeInstance) {
        KogitoWorkflowProcessInstance processInstance = (KogitoWorkflowProcessInstance) nodeInstance.getProcessInstance();

        if (!processInstanceRequiresMigration(processInstance)) {
            LOGGER.trace("Skipping migration: Process instance doesn't require migration.");
            return;
        }

        Collection<ProcessInstanceMigration> migrationStack = pimRepository.findUnappliedMigrationsByProcessInstanceId(processInstance.getId());

        if (migrationStack.isEmpty()) {
            LOGGER.debug("Skipping migration of node instance {} ({}): No migrations found", nodeInstance.getId(), nodeInstance.getNodeId());
            return;
        }

        for (ProcessInstanceMigration pendingMigration : migrationStack) {
            if(pendingMigration.getAppliedAt() != null) {
                LOGGER.error("Error migrating node instance '{}' ('{}'): migration already applied!", nodeInstance.getId(), nodeInstance.getNodeId());
                throw new RuntimeException(String.format("Error migrating node instance '%s' ('%s') migration already applied!",  nodeInstance.getId(), nodeInstance.getNodeId()));
            }

            Optional<MigrationPlan> migrationPlan = processInstanceMigrationPlanRepository.findById(pendingMigration.getPlanId());

            Collection<NodeMapping> nodeMapping = migrationPlan.get().getNodeMapping();

            if (nodeMapping == null || nodeMapping.isEmpty()) {
                LOGGER.debug("Skipping node migration: Plan doesn't have a node mapping. node ({})", nodeInstance.getNodeId());
                break;
            }

            NodeInstanceImpl nodeInstanceImpl = (NodeInstanceImpl) nodeInstance;
            List<NodeMapping> filteredNodeMapping = nodeMapping.stream()
                    .filter(e -> e.getSourceId().equals(nodeInstance.getNodeId().toExternalFormat()))
                    .toList();

            if (filteredNodeMapping.isEmpty()) {
                LOGGER.debug("Skipping migration for node '{}' ('{}')", nodeInstance.getId(), nodeInstance.getNodeId());
                nodeInstanceImpl.setNodeId(nodeInstance.getNodeId());
            } else if (filteredNodeMapping.size() > 1) {
                LOGGER.error("Skipping migration for node '{}' ('{}')", nodeInstance.getId(), nodeInstance.getNodeId());
                throw new RuntimeException("Skipping node migration: Plan has more than one mapping for node" );
            } else {
                WorkflowElementIdentifier targetNodeId = WorkflowElementIdentifierFactory.fromExternalFormat(filteredNodeMapping.get(0).getTargetId());
                nodeInstanceImpl.setNodeId(targetNodeId);
            }
        }
    }

    private boolean processInstanceRequiresMigration(KogitoWorkflowProcessInstance processInstance) {
        Process process = processInstance.getProcess();
        return !process.getId().equals(processInstance.getProcessId()) ||
                !process.getVersion().equals(processInstance.getProcessVersion());
    }
}
