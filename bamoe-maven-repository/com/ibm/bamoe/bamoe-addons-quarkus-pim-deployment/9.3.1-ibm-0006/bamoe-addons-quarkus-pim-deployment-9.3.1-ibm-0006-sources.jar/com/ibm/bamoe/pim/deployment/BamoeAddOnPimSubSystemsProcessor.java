/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.deployment;

import com.ibm.bamoe.pim.subsystem.dataIndex.QuarkusDataIndexSubsystem;
import com.ibm.bamoe.pim.subsystem.usertasks.QuarkusUserTasksSubsystem;
import io.quarkus.arc.deployment.AdditionalBeanBuildItem;
import io.quarkus.arc.processor.DotNames;
import io.quarkus.deployment.Capabilities;
import io.quarkus.deployment.annotations.BuildProducer;
import io.quarkus.deployment.annotations.BuildStep;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class BamoeAddOnPimSubSystemsProcessor {
    private static final Logger LOGGER = LoggerFactory.getLogger(BamoeAddOnPimSubSystemsProcessor.class);

    protected static final String DATA_INDEX_CAPABILITY = "org.kie.kogito.data-index";
    protected static final String USER_TASKS_CAPABILITY = "org.jbpm.addons.usertask.storage";

    @BuildStep
    void registerBAMOESubsystem(Capabilities capabilities,
            BuildProducer<AdditionalBeanBuildItem> additionalBeanBuildItemBuildProducer) {

        LOGGER.debug("Registering BAMOE PIM Subsystems");

        List<AdditionalBeanBuildItem> additionalBeans = new ArrayList<>();

        if (capabilities.isPresent(DATA_INDEX_CAPABILITY)) {
            LOGGER.debug("Found Data Index SubSystem...");
            additionalBeans.add(AdditionalBeanBuildItem.builder().addBeanClass(QuarkusDataIndexSubsystem.class).setUnremovable().setDefaultScope(DotNames.APPLICATION_SCOPED).build());
        }

        if(capabilities.isPresent(USER_TASKS_CAPABILITY)) {
            LOGGER.debug("Found jBPM User Tasks Storage Subsystem...");
            additionalBeans.add(AdditionalBeanBuildItem.builder().addBeanClass(QuarkusUserTasksSubsystem.class).setUnremovable().setDefaultScope(DotNames.APPLICATION_SCOPED).build());
        }

        additionalBeanBuildItemBuildProducer.produce(additionalBeans);
    }

}
