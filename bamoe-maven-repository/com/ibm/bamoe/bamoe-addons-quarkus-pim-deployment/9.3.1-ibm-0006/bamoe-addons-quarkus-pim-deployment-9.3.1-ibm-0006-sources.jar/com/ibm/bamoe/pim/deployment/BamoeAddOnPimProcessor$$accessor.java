package com.ibm.bamoe.pim.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class BamoeAddOnPimProcessor$$accessor {
    private BamoeAddOnPimProcessor$$accessor() {}
    public static Object construct() {
        return new BamoeAddOnPimProcessor();
    }
}
