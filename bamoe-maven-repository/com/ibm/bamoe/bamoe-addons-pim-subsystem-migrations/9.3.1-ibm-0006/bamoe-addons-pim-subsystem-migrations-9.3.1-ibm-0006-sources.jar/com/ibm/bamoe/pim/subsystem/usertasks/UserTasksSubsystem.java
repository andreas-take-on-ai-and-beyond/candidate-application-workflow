/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystem;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;
import com.ibm.bamoe.pim.subsystem.usertasks.sql.UserTasksMigrationSQLQueries;
import org.kie.kogito.usertask.UserTasks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

public class UserTasksSubsystem  implements BamoeSubsystem {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserTasksSubsystem.class);

    private final DataSource dataSource;
    private final UserTasks userTasks;

    private final UserTasksMigrationSQLQueries userTasksMigrationSQLQueries;

    public UserTasksSubsystem() {
        this(null, null, null);
    }

    public UserTasksSubsystem(DataSource dataSource, UserTasks userTasks, UserTasksMigrationSQLQueries  userTasksMigrationSQLQueries) {
        this.dataSource = dataSource;
        this.userTasks = userTasks;
        this.userTasksMigrationSQLQueries = userTasksMigrationSQLQueries;
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {
        if(userTasks == null) {
            LOGGER.info("Skipping jBPM User Tasks migration {}, plan {} no UserTasks available in the Business Service.", migrationId, migrationPlan.getId());
            return;
        }

        LOGGER.info("Migrating jBPM User Tasks with migration {} and planId {} ", migrationId, migrationPlan.getId());

        long startTime = System.currentTimeMillis();

        MergeSQLStatement migrateUserTasksSqlStatement = migrationPlan.getNodeMapping().isEmpty() ? this.userTasksMigrationSQLQueries.getUpdateUserTasksWithoutNodeMappingMigrationSQL() : userTasksMigrationSQLQueries.getUpdateUserTasksMigrationSQL();

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateUserTaskStmt = connection.prepareStatement(migrateUserTasksSqlStatement.getStatement());
                PreparedStatement userTaskRootPidStmt = connection.prepareStatement(userTasksMigrationSQLQueries.getUpdateUserTasksRootProcessIdMigrationSQL().getStatement())) {

            updateUserTaskStmt.setString(1, migrationPlan.getSourceProcessId());
            updateUserTaskStmt.setString(2, migrationId);
            updateUserTaskStmt.setString(3, migrationPlan.getId());

            int instancesCount = updateUserTaskStmt.executeUpdate();
            LOGGER.info("Migrated {} jBPM User Tasks in {}", instancesCount, getTime(System.currentTimeMillis() - startTime));

            userTaskRootPidStmt.setString(1, migrationPlan.getSourceProcessId());
            userTaskRootPidStmt.setString(2, migrationId);
            userTaskRootPidStmt.setString(3, migrationPlan.getId());

            instancesCount = userTaskRootPidStmt.executeUpdate();
            LOGGER.info("Migrated Root Process Id in {} jBPM User tasks in {}", instancesCount, getTime(System.currentTimeMillis() - startTime));
        } catch (SQLException e) {
            LOGGER.error("Couldn't migrate jBPM User Tasks with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't migrate jBPM User Tasks with migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }

    String getTime(long ms) {
        long seconds = TimeUnit.MILLISECONDS.toSeconds(ms);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(ms);

        return "%s minutes (%s seconds/%s milliseconds)".formatted(minutes, seconds, ms);
    }
}
