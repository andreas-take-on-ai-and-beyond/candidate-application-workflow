/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem;

public class BamoeSubsystemMigrationException extends RuntimeException{
    public BamoeSubsystemMigrationException(String message) {
        super(message);
    }

    public BamoeSubsystemMigrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
