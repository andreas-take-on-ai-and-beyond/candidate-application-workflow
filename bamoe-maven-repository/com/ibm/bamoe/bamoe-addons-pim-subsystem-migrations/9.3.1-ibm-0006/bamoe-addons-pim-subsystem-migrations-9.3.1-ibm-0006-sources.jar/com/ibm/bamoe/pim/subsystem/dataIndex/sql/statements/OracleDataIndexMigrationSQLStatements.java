/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements;

public interface OracleDataIndexMigrationSQLStatements {

    String MERGE_NODES_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO nodes USING ( %s ) src " +
            "ON (nodes.id = src.id) WHEN MATCHED THEN UPDATE SET definition_id = src.unique_id, node_id = src.unique_id, name = src.name, type = src.type";

    String MERGE_USER_TASKS_WITH_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE = "MERGE INTO tasks USING ( WITH %s %s ) src " +
            "ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, name = src.task_name, reference_name = src.task_reference_name, user_task_id = src.task_id, " +
            "endpoint = REPLACE(tasks.endpoint, concat('/', tasks.process_id, '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id), concat('/', src.target_process_id , '/', tasks.process_instance_id, '/', src.task_name, '/', tasks.external_reference_id))";

    String MERGE_USER_TASKS_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO tasks USING ( %s ) src " +
            "ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, " +
            "endpoint = REPLACE(tasks.endpoint, concat('/', tasks.process_id, '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id), concat('/', src.target_process_id , '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id))";

    String MERGE_USER_TASKS_ROOT_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO tasks USING ( %s ) src " +
            "ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET root_process_id = ?";
}
