/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystem;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.JobEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.NodeInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.ProcessInstanceEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.migrations.UserTaskInstanceEntityMigration;

import java.util.Collection;
import java.util.List;

public class DataIndexSubsystem implements BamoeSubsystem {

    private Collection<DataIndexEntityMigration> dataIndexEntityMigrations;

    protected DataIndexSubsystem() {
    }

    public DataIndexSubsystem(ProcessInstanceEntityMigration processInstances, UserTaskInstanceEntityMigration userTasks, NodeInstanceEntityMigration nodeInstances, JobEntityMigration jobs) {
        this.dataIndexEntityMigrations = List.of(processInstances, userTasks, nodeInstances, jobs);
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {
        this.dataIndexEntityMigrations.forEach(dataIndexEntityMigration -> dataIndexEntityMigration.migrate(migrationId, migrationPlan));
    }
}
