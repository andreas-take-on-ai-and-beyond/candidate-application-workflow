/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.database;

import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

public class DataBaseTypeHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(DataBaseTypeHelper.class);

    private static final String NORMALIZED_DATABASE_NAME_REGEX = "[^a-zA-Z0-9]+";

    private DataBaseTypeHelper() {
    }

    public static DataBaseType lookupDataBaseType(DataSource dataSource) {
        try (Connection con = dataSource.getConnection()) {

            DatabaseMetaData metadata = con.getMetaData();

            String name = metadata.getDatabaseProductName();

            LOGGER.debug(String.format("Found database name '%s'.", name));

            String[] fragments = name.split(NORMALIZED_DATABASE_NAME_REGEX);

            return DataBaseType.fromName(String.join("-", fragments).toLowerCase());
        } catch (Exception e) {
            LOGGER.error("BAMOE Pim: Couldn't extract database name from datasource", e);
            throw new BamoeSubsystemMigrationException("BAMOE Pim: Couldn't extract database name from datasource", e);
        }
    }

    public static ProcessInstanceMigrationManagementService.Configuration createDbSpecificServiceConfiguration(DataBaseType dataBaseType) {
        return new ProcessInstanceMigrationManagementService.Configuration() {
            @Override
            public int maxMigrationBulkSize() {
                return dataBaseType.getMaxMigrationBulkSize();
            }
        };
    }
}
