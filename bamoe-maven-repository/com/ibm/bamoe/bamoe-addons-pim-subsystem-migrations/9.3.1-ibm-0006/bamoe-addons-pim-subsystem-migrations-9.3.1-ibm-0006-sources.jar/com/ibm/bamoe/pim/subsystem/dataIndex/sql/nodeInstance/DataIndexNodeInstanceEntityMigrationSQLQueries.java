/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;

public interface DataIndexNodeInstanceEntityMigrationSQLQueries {

    MergeSQLStatement getMigrateNodeInstanceSQL();

    MergeSQLStatement getMigrateNodeInstanceWithNodeMappingSQL();

}
