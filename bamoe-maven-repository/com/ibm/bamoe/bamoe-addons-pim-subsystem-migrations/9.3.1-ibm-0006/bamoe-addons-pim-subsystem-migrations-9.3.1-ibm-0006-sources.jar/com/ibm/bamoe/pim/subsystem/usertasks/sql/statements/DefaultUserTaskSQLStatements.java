/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql.statements;

public interface DefaultUserTaskSQLStatements {

    String UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY = "SELECT ut.id, cte_td.task_id, cte_td.task_name, cte_td.task_reference_name, pimp.target_process_id, pimp.target_process_version " +
            "FROM jbpm_user_tasks ut JOIN bamoe_process_instance_migration pim ON (pim.process_instance_id = ut.process_instance_id) " +
            "JOIN bamoe_process_instance_migration_plans pimp ON (pimp.id = pim.process_instance_migration_plan_id) " +
            "JOIN bamoe_process_instance_migration_plan_node_mappings pim_nm ON (pim_nm.process_instance_migration_plan_id = pimp.id AND pim_nm.source_id = ut.user_task_id) " +
            "JOIN cte_task_definitions cte_td ON pim_nm.target_id = cte_td.task_id " +
            "WHERE ut.process_id = ? AND (pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? AND pim.applied_at IS NULL)";

    String UPDATE_USER_TASKS_DEFINITION_WITHOUT_NODE_MAPPING_QUERY = "SELECT ut.id, pimp.target_process_id, pimp.target_process_version " +
            "FROM jbpm_user_tasks ut JOIN bamoe_process_instance_migration pim ON (pim.process_instance_id = ut.process_instance_id) " +
            "JOIN bamoe_process_instance_migration_plans pimp ON (pimp.id = pim.process_instance_migration_plan_id) " +
            "WHERE ut.process_id = ? AND (pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? AND pim.applied_at IS NULL)";

    String MERGE_USER_TASKS_MERGE_STATEMENT_TEMPLATE = "MERGE INTO jbpm_user_tasks USING ( WITH %s %s ) AS src " +
            "ON jbpm_user_tasks.id = src.id WHEN MATCHED THEN UPDATE SET task_name = src.task_name, user_task_id = src.task_id, process_id = src.target_process_id, process_version = src.target_process_version";

    String MERGE_USER_TASKS_WITHOUT_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE = "MERGE INTO jbpm_user_tasks USING ( %s ) AS src " +
            "ON jbpm_user_tasks.id = src.id WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, process_version = src.target_process_version";

    String SELECT_TASK_BY_ROOT_PID_QUERY = "SELECT ut.id, pimp.target_process_id " +
            "FROM jbpm_user_tasks ut JOIN bamoe_process_instance_migration pim ON (pim.process_instance_id = ut.root_process_instance_id) " +
            "JOIN bamoe_process_instance_migration_plans pimp ON (pimp.id = pim.process_instance_migration_plan_id) " +
            "WHERE ut.process_id = ? AND (pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? AND pim.applied_at IS NULL)";

    String MERGE_USER_TASK_ROOT_PROCESS_ID_STATEMENT_TEMPLATE =  "MERGE INTO jbpm_user_tasks USING ( %s ) AS src " +
            "ON jbpm_user_tasks.id = src.id WHEN MATCHED THEN UPDATE SET root_process_id = src.target_process_id";

}
