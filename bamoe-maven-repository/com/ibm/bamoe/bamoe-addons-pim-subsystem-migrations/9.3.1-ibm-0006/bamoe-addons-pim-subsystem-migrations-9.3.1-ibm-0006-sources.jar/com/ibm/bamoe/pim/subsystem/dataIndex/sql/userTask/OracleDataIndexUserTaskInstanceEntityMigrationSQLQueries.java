/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatementRecord;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.UPDATE_USER_TASKS_PROCESS_ID_QUERY_STATEMENT;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.UPDATE_USER_TASK_ROOT_PROCESS_ID_QUERY_STATEMENT;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.OracleDataIndexMigrationSQLStatements.MERGE_USER_TASKS_ROOT_PROCESS_ID_MERGE_STATEMENT_TEMPLATE;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.OracleDataIndexMigrationSQLStatements.MERGE_USER_TASKS_PROCESS_ID_MERGE_STATEMENT_TEMPLATE;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.OracleDataIndexMigrationSQLStatements.MERGE_USER_TASKS_WITH_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE;

public class OracleDataIndexUserTaskInstanceEntityMigrationSQLQueries extends AbstractDataIndexUserTaskInstanceEntityMigrationSQLQueries {

    public OracleDataIndexUserTaskInstanceEntityMigrationSQLQueries(TaskDefinitionCteSQLStatement taskDefinitionCTESQLStatement) {
        super(new MergeSQLStatementRecord(MERGE_USER_TASKS_WITH_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE, taskDefinitionCTESQLStatement.getStatement(), UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY),
                new MergeSQLStatementRecord(MERGE_USER_TASKS_PROCESS_ID_MERGE_STATEMENT_TEMPLATE, UPDATE_USER_TASKS_PROCESS_ID_QUERY_STATEMENT),
                new MergeSQLStatementRecord(MERGE_USER_TASKS_ROOT_PROCESS_ID_MERGE_STATEMENT_TEMPLATE, UPDATE_USER_TASK_ROOT_PROCESS_ID_QUERY_STATEMENT));
    }
}
