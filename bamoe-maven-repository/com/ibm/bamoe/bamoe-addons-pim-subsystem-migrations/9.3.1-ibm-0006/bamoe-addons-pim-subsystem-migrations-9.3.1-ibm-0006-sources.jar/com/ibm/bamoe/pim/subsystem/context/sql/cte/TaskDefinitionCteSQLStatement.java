/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.sql.cte;

public class TaskDefinitionCteSQLStatement {

    private String statement;

    public TaskDefinitionCteSQLStatement(String statement) {
        this.statement = statement;
    }
    public String getStatement() {
        return statement;
    }
}
