/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatementRecord;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;

import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.DefaultUserTaskSQLStatements.SELECT_TASK_BY_ROOT_PID_QUERY;
import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.DefaultUserTaskSQLStatements.UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY;
import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.DefaultUserTaskSQLStatements.UPDATE_USER_TASKS_DEFINITION_WITHOUT_NODE_MAPPING_QUERY;
import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.MSSQLUserTaskSQLStatements.MERGE_USER_TASKS_MERGE_STATEMENT_TEMPLATE;
import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.MSSQLUserTaskSQLStatements.MERGE_USER_TASKS_WITHOUT_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE;
import static com.ibm.bamoe.pim.subsystem.usertasks.sql.statements.MSSQLUserTaskSQLStatements.MERGE_USER_TASK_ROOT_PROCESS_ID_STATEMENT_TEMPLATE;

public class MSSQLUserTasksMigrationSQLQueries extends AbstractUserTasksMigrationSQLQueries {

    public MSSQLUserTasksMigrationSQLQueries(TaskDefinitionCteSQLStatement taskDefinitionCTESQLStatement) {
        super(new MergeSQLStatementRecord(MERGE_USER_TASKS_MERGE_STATEMENT_TEMPLATE, taskDefinitionCTESQLStatement.getStatement(), UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY),
                new MergeSQLStatementRecord(MERGE_USER_TASKS_WITHOUT_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE, UPDATE_USER_TASKS_DEFINITION_WITHOUT_NODE_MAPPING_QUERY),
                new MergeSQLStatementRecord(MERGE_USER_TASK_ROOT_PROCESS_ID_STATEMENT_TEMPLATE, SELECT_TASK_BY_ROOT_PID_QUERY));
    }
}
