/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements;

public interface MSSQLDataIndexMigrationSQLStatements {

    // Node Instance Migrations
    String UPDATE_NODES_PROCESS_ID_NO_NODE_MAPPING_QUERY_STATEMENT = "SELECT ni.id, nd.unique_id, nd.name, nd.type " +
            "FROM nodes ni JOIN definitions_nodes nd ON nd.unique_id = ni.definition_id " +
            "JOIN bamoe_process_instance_migration pim ON ni.process_instance_id = pim.process_instance_id " +
            "WHERE nd.process_id = ? AND (ni.exit_time IS NULL AND ni.cancel_type IS NULL) AND pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? AND pim.applied_at IS NULL";

    String UPDATE_NODES_PROCESS_ID_WITH_NODE_MAPPING_QUERY_STATEMENT = "SELECT ni.id, nd.unique_id, nd.name, nd.type " +
            "FROM nodes ni JOIN bamoe_process_instance_migration_plan_node_mappings mp ON mp.source_id = ni.definition_id " +
            "JOIN definitions_nodes nd ON nd.unique_id = mp.target_id " +
            "JOIN bamoe_process_instance_migration pim ON (ni.process_instance_id = pim.process_instance_id AND mp.process_instance_migration_plan_id = pim.process_instance_migration_plan_id) " +
            "WHERE nd.process_id = ? AND (ni.exit_time IS NULL AND ni.cancel_type IS NULL) AND pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? AND pim.applied_at IS NULL";

    String MERGE_NODES_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO nodes USING ( %s ) AS src " +
            "ON (nodes.id = src.id) WHEN MATCHED THEN UPDATE SET definition_id = src.unique_id, node_id = src.unique_id, name = src.name, type = src.type;";

    // User Task Migrations
    String UPDATE_USER_TASKS_DEFINITION_WITH_NODE_MAPPING_QUERY = "SELECT ut.id, utd.task_id, utd.task_name, utd.task_reference_name, pimp.target_process_id " +
            "FROM tasks ut JOIN nodes ni ON (ut.user_task_id = ni.node_id AND ni.process_instance_id = ut.process_instance_id) " +
            "JOIN bamoe_process_instance_migration_plan_node_mappings nmp ON ni.node_id = nmp.source_id " +
            "JOIN cte_task_definitions utd on nmp.target_id = utd.task_id " +
            "JOIN bamoe_process_instance_migration pim ON (ut.process_instance_id = pim.process_instance_id AND nmp.process_instance_migration_plan_id = pim.process_instance_migration_plan_id)" +
            "JOIN bamoe_process_instance_migration_plans pimp ON (pimp.id = pim.process_instance_migration_plan_id AND ut.process_id = pimp.source_process_id)" +
            "WHERE ut.process_id = ? AND (ni.exit_time IS NULL AND ni.cancel_type IS NULL) AND pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? and applied_at IS NULL";

    String UPDATE_USER_TASKS_PROCESS_ID_QUERY_STATEMENT = "SELECT ut.id, pim.process_instance_id, pimp.target_process_id " +
            "FROM tasks ut JOIN nodes ni ON (ut.user_task_id = ni.node_id AND ni.process_instance_id = ut.process_instance_id) " +
            "JOIN bamoe_process_instance_migration pim ON ut.process_instance_id = pim.process_instance_id " +
            "JOIN bamoe_process_instance_migration_plans pimp ON (pimp.id = pim.process_instance_migration_plan_id AND ut.process_id = pimp.source_process_id)" +
            "WHERE (ni.exit_time IS NULL AND ni.cancel_type IS NULL) AND pim.migration_id = ? AND pim.process_instance_migration_plan_id = ? and applied_at IS NULL";

    String UPDATE_USER_TASK_ROOT_PROCESS_ID_QUERY_STATEMENT = "SELECT ut.id " +
            "FROM tasks ut JOIN nodes ni ON (ut.user_task_id = ni.node_id AND ni.process_instance_id = ut.process_instance_id) " +
            "JOIN bamoe_process_instance_migration pim ON ut.root_process_instance_id = pim.process_instance_id " +
            "WHERE (ni.exit_time IS NULL AND ni.cancel_type IS NULL) AND pim.migration_id = ? AND pim.process_instance_migration_plan_id= ? and applied_at IS NULL";

    String MERGE_USER_TASKS_WITH_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE = "WITH %s MERGE INTO tasks USING ( %s ) AS src " +
            "ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, name = src.task_name, reference_name = src.task_reference_name, user_task_id = src.task_id, " +
            "endpoint = REPLACE(tasks.endpoint, concat('/', tasks.process_id, '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id), concat('/', src.target_process_id , '/', tasks.process_instance_id, '/', src.task_name, '/', tasks.external_reference_id));";

    String MERGE_USER_TASKS_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO tasks USING ( %s ) AS src " +
            "ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, " +
            "endpoint = REPLACE(tasks.endpoint, concat('/', tasks.process_id, '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id), concat('/', src.target_process_id , '/', tasks.process_instance_id, '/', tasks.name, '/', tasks.external_reference_id));";

    String MERGE_USER_TASKS_ROOT_PROCESS_ID_MERGE_STATEMENT_TEMPLATE = "MERGE INTO tasks USING ( %s ) AS src ON (tasks.id = src.id) WHEN MATCHED THEN UPDATE SET root_process_id = ?;";
}
