/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;
import com.ibm.bamoe.pim.subsystem.dataIndex.DataIndexEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;
import org.kie.kogito.usertask.UserTasks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserTaskInstanceEntityMigration implements DataIndexEntityMigration {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserTaskInstanceEntityMigration.class);

    private final DataSource dataSource;
    private final UserTasks userTasks;
    private final DataIndexUserTaskInstanceEntityMigrationSQLQueries userTaskEntityMigrationSQL;

    protected UserTaskInstanceEntityMigration() {
        this(null, null, null);
    }

    public UserTaskInstanceEntityMigration(DataSource dataSource, UserTasks userTasks, DataIndexUserTaskInstanceEntityMigrationSQLQueries userTaskEntityMigrationSQL) {
        this.dataSource = dataSource;
        this.userTasks = userTasks;
        this.userTaskEntityMigrationSQL = userTaskEntityMigrationSQL;
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {
        if(userTasks == null) {
            LOGGER.info("Skipping User Task Instances migration {}, plan {} no UserTasks available in the Business Service.", migrationId, migrationPlan.getId());
            return;
        }

        LOGGER.info("Migrating User Tasks with migration {} and planId {} ", migrationId, migrationPlan.getId());

        if (migrationPlan.getNodeMapping().isEmpty()) {
            migrateUserTasksWithoutNodeMapping(migrationId, migrationPlan);
        } else {
            migrateUserTasksWithNodeMapping(migrationId, migrationPlan);
        }
        migrateRootProcessIdReferences(migrationId, migrationPlan);

        LOGGER.info("User Tasks migration {} successfully completed with planId {} ", migrationId, migrationPlan.getId());
    }

    private void migrateUserTasksWithNodeMapping(String migrationId, MigrationPlan migrationPlan) {
        LOGGER.debug("Migrating User Tasks with migration {} and planId {} with node mappings.", migrationId, migrationPlan.getId());


        MergeSQLStatement migrateUserTaskWithNodeMappingSQL = this.userTaskEntityMigrationSQL.getMigrateUserTaskWithNodeMappingSQL();

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateUserTaskStmt = connection.prepareStatement(migrateUserTaskWithNodeMappingSQL.getStatement())) {
            updateUserTaskStmt.setString(1, migrationPlan.getSourceProcessId());
            updateUserTaskStmt.setString(2, migrationId);
            updateUserTaskStmt.setString(3, migrationPlan.getId());

            int instancesCount = updateUserTaskStmt.executeUpdate();
            LOGGER.debug("Migrated {} User Tasks", instancesCount);
        } catch (SQLException e) {
            LOGGER.error("Couldn't migrate User Tasks on Data Index with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't migrate User Tasks on Data Index update migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }

    private void migrateUserTasksWithoutNodeMapping(String migrationId, MigrationPlan migrationPlan) {
        LOGGER.debug("Migrating User Tasks with migration {} and planId {}", migrationId, migrationPlan.getId());

        String fullSQLStatement = this.userTaskEntityMigrationSQL.getMigrateUserTaskSQL().getStatement();

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateUserTaskProcessIdStmt = connection.prepareStatement(fullSQLStatement)) {
            updateUserTaskProcessIdStmt.setString(1, migrationId);
            updateUserTaskProcessIdStmt.setString(2, migrationPlan.getId());
            int processIdCount = updateUserTaskProcessIdStmt.executeUpdate();
            LOGGER.debug("Migrated Process Id in {} User tasks", processIdCount);
        } catch (SQLException e) {
            LOGGER.error("Couldn't update Process Id in User Tasks with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't update Process Id in User Tasks with migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }

    private void migrateRootProcessIdReferences(String migrationId, MigrationPlan migrationPlan) {

        String fullSQLStatement = userTaskEntityMigrationSQL.getMigrateRootProcessIdSQL().getStatement();

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateUserTasksRootPidStmt = connection.prepareStatement(fullSQLStatement)) {
            updateUserTasksRootPidStmt.setString(1, migrationId);
            updateUserTasksRootPidStmt.setString(2, migrationPlan.getId());
            updateUserTasksRootPidStmt.setString(3, migrationPlan.getTargetProcessId());
            int rootProcessIdCount = updateUserTasksRootPidStmt.executeUpdate();
            LOGGER.debug("Migrated Root Process Id in {} User tasks", rootProcessIdCount);
        } catch (SQLException e) {
            LOGGER.error("Couldn't update Process Id in User Tasks with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't update Process Id in User Tasks with migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }
}
