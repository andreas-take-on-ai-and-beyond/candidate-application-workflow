/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;
import com.ibm.bamoe.pim.subsystem.dataIndex.DataIndexEntityMigration;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class NodeInstanceEntityMigration implements DataIndexEntityMigration {

    private static final Logger LOGGER = LoggerFactory.getLogger(NodeInstanceEntityMigration.class);

    private final DataSource dataSource;
    private final DataIndexNodeInstanceEntityMigrationSQLQueries nodeInstanceMigrationSQL;

    public NodeInstanceEntityMigration(DataSource dataSource, DataIndexNodeInstanceEntityMigrationSQLQueries nodeInstanceMigrationSQL) {
        this.dataSource = dataSource;
        this.nodeInstanceMigrationSQL = nodeInstanceMigrationSQL;
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {

        MergeSQLStatement sqlStatement = migrationPlan.getNodeMapping().isEmpty() ? this.nodeInstanceMigrationSQL.getMigrateNodeInstanceSQL() : this.nodeInstanceMigrationSQL.getMigrateNodeInstanceWithNodeMappingSQL();

        LOGGER.info("Migrating Node Instances with migration {} and planId {} ", migrationId, migrationPlan.getId());

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateNodeMappingStmt = connection.prepareStatement(sqlStatement.getStatement())) {
            updateNodeMappingStmt.setString(1, migrationPlan.getTargetProcessId());
            updateNodeMappingStmt.setString(2, migrationId);
            updateNodeMappingStmt.setString(3, migrationPlan.getId());

            int instancesCount = updateNodeMappingStmt.executeUpdate();

            LOGGER.info("{} Node Instances successfully migrated with migration {} and planId {} ", instancesCount, migrationId, migrationPlan.getId());
        } catch (SQLException e) {
            LOGGER.error("Couldn't migrate Node Instances on Data Index with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't migrate Node Instances on Data Index with migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }
}
