/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;

public abstract class AbstractDataIndexNodeInstanceEntityMigrationSQLQueries implements DataIndexNodeInstanceEntityMigrationSQLQueries {

    private final MergeSQLStatement migrateNodeInstanceSQL;
    private final MergeSQLStatement migrateNodeInstanceWithNodeMappingSQL;

    public AbstractDataIndexNodeInstanceEntityMigrationSQLQueries(MergeSQLStatement migrateNodeInstanceSQL, MergeSQLStatement migrateNodeInstanceWithNodeMappingSQL) {
        this.migrateNodeInstanceSQL = migrateNodeInstanceSQL;
        this.migrateNodeInstanceWithNodeMappingSQL = migrateNodeInstanceWithNodeMappingSQL;
    }

    @Override
    public MergeSQLStatement getMigrateNodeInstanceSQL() {
        return migrateNodeInstanceSQL;
    }

    @Override
    public MergeSQLStatement getMigrateNodeInstanceWithNodeMappingSQL() {
        return migrateNodeInstanceWithNodeMappingSQL;
    }
}
