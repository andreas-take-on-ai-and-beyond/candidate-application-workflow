/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatementRecord;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.UPDATE_NODES_PROCESS_ID_NO_NODE_MAPPING_QUERY_STATEMENT;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.UPDATE_NODES_PROCESS_ID_WITH_NODE_MAPPING_QUERY_STATEMENT;
import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.MERGE_NODES_PROCESS_ID_MERGE_STATEMENT_TEMPLATE;

public class DefaultDataIndexNodeInstanceEntityMigrationSQLQueries extends AbstractDataIndexNodeInstanceEntityMigrationSQLQueries {

    public DefaultDataIndexNodeInstanceEntityMigrationSQLQueries() {
        super(new MergeSQLStatementRecord(MERGE_NODES_PROCESS_ID_MERGE_STATEMENT_TEMPLATE, UPDATE_NODES_PROCESS_ID_NO_NODE_MAPPING_QUERY_STATEMENT),
                new MergeSQLStatementRecord(MERGE_NODES_PROCESS_ID_MERGE_STATEMENT_TEMPLATE, UPDATE_NODES_PROCESS_ID_WITH_NODE_MAPPING_QUERY_STATEMENT));
    }
}
