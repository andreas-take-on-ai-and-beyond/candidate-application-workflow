/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;

public abstract class AbstractDataIndexUserTaskInstanceEntityMigrationSQLQueries implements DataIndexUserTaskInstanceEntityMigrationSQLQueries {
    private final MergeSQLStatement migrateUserTaskWithNodeMappingSQL;
    private final MergeSQLStatement migrateUserTaskWithoutNodeMappingSQL;
    private final MergeSQLStatement migrateRootProcessIdSQL;

    public AbstractDataIndexUserTaskInstanceEntityMigrationSQLQueries(MergeSQLStatement migrateUserTaskWithNodeMappingSQL, MergeSQLStatement migrateUserTaskWithoutNodeMappingSQL,
            MergeSQLStatement migrateRootProcessIdSQL) {
        this.migrateUserTaskWithNodeMappingSQL = migrateUserTaskWithNodeMappingSQL;
        this.migrateUserTaskWithoutNodeMappingSQL = migrateUserTaskWithoutNodeMappingSQL;
        this.migrateRootProcessIdSQL = migrateRootProcessIdSQL;
    }

    @Override
    public MergeSQLStatement getMigrateUserTaskWithNodeMappingSQL() {
        return this.migrateUserTaskWithNodeMappingSQL;
    }

    @Override
    public MergeSQLStatement getMigrateUserTaskSQL() {
        return this.migrateUserTaskWithoutNodeMappingSQL;
    }

    @Override
    public MergeSQLStatement getMigrateRootProcessIdSQL() {
        return this.migrateRootProcessIdSQL;
    }
}
