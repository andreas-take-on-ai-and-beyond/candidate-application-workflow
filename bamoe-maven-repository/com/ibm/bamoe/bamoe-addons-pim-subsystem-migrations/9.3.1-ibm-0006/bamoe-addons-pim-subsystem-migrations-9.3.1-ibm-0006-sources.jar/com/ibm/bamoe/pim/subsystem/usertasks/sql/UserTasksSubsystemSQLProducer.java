/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql;

import com.ibm.bamoe.pim.subsystem.context.database.DataBaseType;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;

public class UserTasksSubsystemSQLProducer {

    public static UserTasksMigrationSQLQueries fromDatabaseType(DataBaseType dataBaseType, TaskDefinitionCteSQLStatement taskDefinitionCTESQLStatement) {
        return switch (dataBaseType) {
            case ORACLE -> new OracleUserTasksMigrationSQLQueries(taskDefinitionCTESQLStatement);
            case MSSQL -> new MSSQLUserTasksMigrationSQLQueries(taskDefinitionCTESQLStatement);
            default -> new DefaultUserTasksMigrationSQLQueries(taskDefinitionCTESQLStatement);
        };
    }
}
