/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import com.ibm.bamoe.pim.subsystem.dataIndex.DataIndexEntityMigration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.*;

public class JobEntityMigration implements DataIndexEntityMigration {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobEntityMigration.class);

    private DataSource dataSource;

    public JobEntityMigration(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {
        LOGGER.info("Migrating Jobs with migration {} for planId {} ", migrationId, migrationPlan.getId());

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateJobsPidStmt = connection.prepareStatement(UPDATE_JOBS_STATEMENT);
                PreparedStatement updateJobsRootPidStmt = connection.prepareStatement(UPDATE_JOBS_ROOT_PROCESS_ID_STATEMENT)) {
            updateJobsPidStmt.setString(1, migrationPlan.getTargetProcessId());
            updateJobsPidStmt.setString(2, migrationPlan.getSourceProcessId());
            updateJobsPidStmt.setString(3, migrationId);
            updateJobsPidStmt.setString(4, migrationPlan.getId());
            int instancesCount = updateJobsPidStmt.executeUpdate();
            LOGGER.debug("Migrated Process Id in {} Jobs", instancesCount);

            updateJobsRootPidStmt.setString(1, migrationPlan.getTargetProcessId());
            updateJobsRootPidStmt.setString(2, migrationPlan.getSourceProcessId());
            updateJobsRootPidStmt.setString(3, migrationId);
            updateJobsRootPidStmt.setString(4, migrationPlan.getId());

            int rootProcessIdCount = updateJobsRootPidStmt.executeUpdate();
            LOGGER.debug("Migrated Root Process Id in {} Jobs", rootProcessIdCount);

            LOGGER.info("Jobs migration {} successfully completed with planId {} ", migrationId, migrationPlan.getId());
        } catch (SQLException e) {
            LOGGER.error("Couldn't migrate Jobs on Data Index with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't migrate Jobs on Data Index for migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }
}
