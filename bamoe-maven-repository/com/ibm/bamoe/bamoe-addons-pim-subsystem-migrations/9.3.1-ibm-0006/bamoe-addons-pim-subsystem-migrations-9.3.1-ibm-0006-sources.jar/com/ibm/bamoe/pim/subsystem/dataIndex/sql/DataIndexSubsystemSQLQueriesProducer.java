/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql;

import com.ibm.bamoe.pim.subsystem.context.database.DataBaseType;
import com.ibm.bamoe.pim.subsystem.context.sql.cte.TaskDefinitionCteSQLStatement;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DefaultDataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.DataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.MSSQLDataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.nodeInstance.OracleDataIndexNodeInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DefaultDataIndexUserTaskInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.MSSQLDataIndexUserTaskInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.OracleDataIndexUserTaskInstanceEntityMigrationSQLQueries;
import com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask.DataIndexUserTaskInstanceEntityMigrationSQLQueries;

public class DataIndexSubsystemSQLQueriesProducer {

    public static DataIndexUserTaskInstanceEntityMigrationSQLQueries getUserTaskInstanceEntityMigrationSQLQueriesFromDataBaseType(DataBaseType dataBaseType, TaskDefinitionCteSQLStatement taskDefinitionCTESQLStatement) {
        return switch (dataBaseType) {
            case ORACLE -> new OracleDataIndexUserTaskInstanceEntityMigrationSQLQueries(taskDefinitionCTESQLStatement);
            case MSSQL -> new MSSQLDataIndexUserTaskInstanceEntityMigrationSQLQueries(taskDefinitionCTESQLStatement);
            default -> new DefaultDataIndexUserTaskInstanceEntityMigrationSQLQueries(taskDefinitionCTESQLStatement);
        };
    }

    public static DataIndexNodeInstanceEntityMigrationSQLQueries getNodeInstanceEntityMigrationFromDatabaseType(DataBaseType dataBaseType) {
        return switch (dataBaseType) {
            case ORACLE -> new OracleDataIndexNodeInstanceEntityMigrationSQLQueries();
            case MSSQL -> new MSSQLDataIndexNodeInstanceEntityMigrationSQLQueries();
            default -> new DefaultDataIndexNodeInstanceEntityMigrationSQLQueries();
        };
    }
}
