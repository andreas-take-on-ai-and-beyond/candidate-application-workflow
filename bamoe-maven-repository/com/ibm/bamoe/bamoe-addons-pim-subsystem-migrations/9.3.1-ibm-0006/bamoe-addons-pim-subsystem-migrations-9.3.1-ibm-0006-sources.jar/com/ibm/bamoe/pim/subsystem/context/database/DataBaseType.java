/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.database;


import com.ibm.bamoe.pim.api.service.ProcessInstanceMigrationManagementService;

import java.util.Arrays;

public enum DataBaseType {
    H2("h2", ProcessInstanceMigrationManagementService.Configuration.DEFAULT_MAX_MIGRATION_BULK_SIZE),
    POSTGRESQL("postgresql", 50000),
    ORACLE("oracle", 1000),
    MSSQL("microsoft-sql-server", 2000);

    private final String name;
    private final int maxMigrationBulkSize;

    DataBaseType(String name, int maxMigrationBulkSize) {
        this.name = name;
        this.maxMigrationBulkSize = maxMigrationBulkSize;
    }

    public String getName() {
        return name;
    }

    static DataBaseType fromName(String name) {
        return Arrays.stream(values()).filter(t -> t.name.equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new IllegalArgumentException("Unknown Data Base Type"));
    }

    public int getMaxMigrationBulkSize() {
        return maxMigrationBulkSize;
    }
}

