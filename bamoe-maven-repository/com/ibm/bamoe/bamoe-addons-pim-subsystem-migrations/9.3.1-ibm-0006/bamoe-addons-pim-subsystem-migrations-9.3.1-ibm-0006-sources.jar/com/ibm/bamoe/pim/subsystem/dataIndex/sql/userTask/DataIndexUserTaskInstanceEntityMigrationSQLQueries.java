/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.sql.userTask;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;

public interface DataIndexUserTaskInstanceEntityMigrationSQLQueries {

    MergeSQLStatement getMigrateUserTaskWithNodeMappingSQL();

    MergeSQLStatement getMigrateUserTaskSQL();

    MergeSQLStatement getMigrateRootProcessIdSQL();
}
