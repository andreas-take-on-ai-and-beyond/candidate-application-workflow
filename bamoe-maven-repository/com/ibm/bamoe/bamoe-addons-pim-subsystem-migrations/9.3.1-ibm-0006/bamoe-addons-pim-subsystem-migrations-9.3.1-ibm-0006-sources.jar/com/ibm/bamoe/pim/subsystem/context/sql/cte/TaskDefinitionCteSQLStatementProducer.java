/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.sql.cte;

import org.kie.kogito.usertask.UserTasks;

import java.util.Optional;

public class TaskDefinitionCteSQLStatementProducer {

    static String VALUE_ENTRY_TEMPLATE = "('%s', '%s', '%s')";

    private TaskDefinitionCteSQLStatementProducer() {
        // Utils class no instantiable
    }

    public static TaskDefinitionCteSQLStatement buildTaskDefinitionCteSQLStatement(Optional<UserTasks> userTasks) {
        return userTasks.map(tasks -> new TaskDefinitionCteSQLStatement(buildTaskDefinitionsCTEStatement(tasks))).orElseGet(() -> new TaskDefinitionCteSQLStatement(null));
    }

    private static String buildTaskDefinitionsCTEStatement(UserTasks userTasks) {
        StringBuilder cteStatement = new StringBuilder("cte_task_definitions (task_id, task_name, task_reference_name) AS (")
                .append("SELECT * FROM (VALUES ");

        StringBuilder cteValues = new StringBuilder();

        userTasks.userTaskIds().stream()
                .map(userTasks::userTaskById)
                .forEach(userTask -> {
                    if (!cteValues.isEmpty()) {
                        cteValues.append(", ");
                    }
                    cteValues.append(VALUE_ENTRY_TEMPLATE.formatted(userTask.id(), userTask.name(), userTask.getReferenceName()));
                });

        cteStatement.append(cteValues);
        cteStatement.append(") AS A (task_id, task_name, task_reference_name)) ");

        return cteStatement.toString();
    }
}
