/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem;

import com.ibm.bamoe.pim.migration.event.NewMigrationEvent;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseSubsystemMigrator implements SubsystemMigrator {

    private final List<BamoeSubsystem> registeredSubsystems;

    protected BaseSubsystemMigrator() {
        this.registeredSubsystems = new ArrayList<>();
    }

    public BaseSubsystemMigrator(Iterable<BamoeSubsystem> subsystems) {
        this();
        subsystems.forEach(registeredSubsystems::add);
    }

    @Override
    public void migrate(NewMigrationEvent migrationEvent) {
        this.registeredSubsystems.forEach(bamoeSubsystem -> bamoeSubsystem.migrate(migrationEvent.getMigrationId(), migrationEvent.getMigrationPlan()));
    }
}
