/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.context.sql.api;


public record MergeSQLStatementRecord(String mergeStatement, String... mergeSelectQueries) implements MergeSQLStatement {

    public String getStatement() {
        return mergeStatement.formatted((Object[]) mergeSelectQueries);
    }
}
