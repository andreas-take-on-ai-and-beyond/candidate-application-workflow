/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql.statements;

public interface OracleUserTaskSQLStatements {

    String MERGE_USER_TASKS_MERGE_STATEMENT_TEMPLATE = "MERGE INTO jbpm_user_tasks USING (WITH %s %s) src " +
            "ON (jbpm_user_tasks.id = src.id) WHEN MATCHED THEN UPDATE SET task_name = src.task_name, user_task_id = src.task_id, process_id = src.target_process_id, process_version = src.target_process_version";

    String MERGE_USER_TASKS_WITHOUT_NODE_MAPPING_MERGE_STATEMENT_TEMPLATE = "MERGE INTO jbpm_user_tasks USING ( %s ) src " +
            "ON (jbpm_user_tasks.id = src.id) WHEN MATCHED THEN UPDATE SET process_id = src.target_process_id, process_version = src.target_process_version";

    String MERGE_USER_TASK_ROOT_PROCESS_ID_STATEMENT_TEMPLATE =  "MERGE INTO jbpm_user_tasks USING ( %s ) src " +
            "ON (jbpm_user_tasks.id = src.id) WHEN MATCHED THEN UPDATE SET root_process_id = src.target_process_id";

}
