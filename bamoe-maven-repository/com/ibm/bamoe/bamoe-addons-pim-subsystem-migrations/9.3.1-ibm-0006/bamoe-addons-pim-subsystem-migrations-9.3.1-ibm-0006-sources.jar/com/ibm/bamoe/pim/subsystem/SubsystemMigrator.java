/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem;

import com.ibm.bamoe.pim.migration.event.NewMigrationEvent;

public interface SubsystemMigrator {
    void migrate(NewMigrationEvent migrationEvent);
}
