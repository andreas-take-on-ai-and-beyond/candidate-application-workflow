/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.usertasks.sql;

import com.ibm.bamoe.pim.subsystem.context.sql.api.MergeSQLStatement;

public class AbstractUserTasksMigrationSQLQueries implements UserTasksMigrationSQLQueries {

    private final MergeSQLStatement userTaskMigrationSQL;
    private final MergeSQLStatement userTasksMigrationWithoutNodeMappingSQL;
    private final MergeSQLStatement updateUserTasksRootProcessIdMigrationSQL;

    public AbstractUserTasksMigrationSQLQueries(MergeSQLStatement userTaskMigrationSQL,
            MergeSQLStatement userTasksMigrationWithoutNodeMappingSQL,
            MergeSQLStatement updateUserTasksRootProcessIdMigrationSQL) {
        this.userTaskMigrationSQL = userTaskMigrationSQL;
        this.userTasksMigrationWithoutNodeMappingSQL = userTasksMigrationWithoutNodeMappingSQL;
        this.updateUserTasksRootProcessIdMigrationSQL = updateUserTasksRootProcessIdMigrationSQL;
    }

    @Override
    public MergeSQLStatement getUpdateUserTasksMigrationSQL() {
        return userTaskMigrationSQL;
    }

    @Override
    public MergeSQLStatement getUpdateUserTasksWithoutNodeMappingMigrationSQL() {
        return userTasksMigrationWithoutNodeMappingSQL;
    }

    @Override
    public MergeSQLStatement getUpdateUserTasksRootProcessIdMigrationSQL() {
        return this.updateUserTasksRootProcessIdMigrationSQL;
    }
}
