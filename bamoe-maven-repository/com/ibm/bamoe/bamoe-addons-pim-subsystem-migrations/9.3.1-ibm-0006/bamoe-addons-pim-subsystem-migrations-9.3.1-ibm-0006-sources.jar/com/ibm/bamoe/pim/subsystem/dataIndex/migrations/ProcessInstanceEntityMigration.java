/**
* IBM Confidential
* PID 5900-AR4
* Copyright IBM Corp. 2025 
*/
package com.ibm.bamoe.pim.subsystem.dataIndex.migrations;

import com.ibm.bamoe.pim.api.model.MigrationPlan;
import com.ibm.bamoe.pim.subsystem.BamoeSubsystemMigrationException;
import com.ibm.bamoe.pim.subsystem.dataIndex.DataIndexEntityMigration;
import org.kie.kogito.process.Processes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static com.ibm.bamoe.pim.subsystem.dataIndex.sql.statements.DefaultDataIndexMigrationSQLStatements.*;

public class ProcessInstanceEntityMigration implements DataIndexEntityMigration {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessInstanceEntityMigration.class);

    private DataSource dataSource;
    private Processes processes;

    public ProcessInstanceEntityMigration(DataSource dataSource, Processes processes) {
        this.dataSource = dataSource;
        this.processes = processes;
    }

    @Override
    public void migrate(String migrationId, MigrationPlan migrationPlan) {
        LOGGER.info("Migrating Process Instances with migration {} and planId {} ", migrationId, migrationPlan.getId());

        String targetProcessName = processes.processById(migrationPlan.getTargetProcessId()).name();

        try (Connection connection = dataSource.getConnection();
                PreparedStatement updateInstancesStmt = connection.prepareStatement(UPDATE_PROCESS_INSTANCES_STATEMENT);
                PreparedStatement updateRootProcesStmt = connection.prepareStatement(UPDATE_ROOT_PROCESS_ID_STATEMENT)) {
            updateInstancesStmt.setString(1, migrationPlan.getTargetProcessId());
            updateInstancesStmt.setString(2, targetProcessName);
            updateInstancesStmt.setString(3, migrationPlan.getTargetProcessVersion());
            updateInstancesStmt.setString(4, "/" + migrationPlan.getSourceProcessId());
            updateInstancesStmt.setString(5, "/" + migrationPlan.getTargetProcessId());
            updateInstancesStmt.setString(6, migrationPlan.getSourceProcessId());
            updateInstancesStmt.setString(7, migrationId);
            updateInstancesStmt.setString(8, migrationPlan.getId());
            int instancesCount = updateInstancesStmt.executeUpdate();
            LOGGER.debug("Successfully migrated {} Process instances", instancesCount);

            updateRootProcesStmt.setString(1, migrationPlan.getTargetProcessId());
            updateRootProcesStmt.setString(2, migrationPlan.getSourceProcessId());
            updateRootProcesStmt.setString(3, migrationId);
            updateRootProcesStmt.setString(4, migrationPlan.getId());
            int rootProcessIdCount = updateRootProcesStmt.executeUpdate();
            LOGGER.debug("Successfully migrated {} subprocesses", rootProcessIdCount);

            LOGGER.info("Process Instances migration {} successfully completed with planId {} ", migrationId, migrationPlan.getId());
        } catch (SQLException e) {
            LOGGER.error("Couldn't migrate Process Instances with migration {} and planId {} ", migrationId, migrationPlan.getId(), e);
            throw new BamoeSubsystemMigrationException("Couldn't migrate Process Instances on Data Index with migration %s and plan %s".formatted(migrationId, migrationPlan.getId()), e);
        }
    }
}
