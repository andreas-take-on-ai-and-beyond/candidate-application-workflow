package org.kie.kogito.eventdriven.rules;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnEventRulesProcessor$$accessor {
    private KogitoAddOnEventRulesProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnEventRulesProcessor();
    }
}
