package org.kie.flyway.quarkus;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KieFlywayQuarkusRuntimeConfig$KieQuarkusFlywayNamedModule$$accessor {
    private KieFlywayQuarkusRuntimeConfig$KieQuarkusFlywayNamedModule$$accessor() {}
    @SuppressWarnings("unchecked")
    public static boolean get_enabled(Object __instance) {
        return ((org.kie.flyway.quarkus.KieFlywayQuarkusRuntimeConfig.KieQuarkusFlywayNamedModule)__instance).enabled;
    }
    @SuppressWarnings("unchecked")
    public static void set_enabled(Object __instance, boolean enabled) {
        ((org.kie.flyway.quarkus.KieFlywayQuarkusRuntimeConfig.KieQuarkusFlywayNamedModule)__instance).enabled = enabled;
    }
}
