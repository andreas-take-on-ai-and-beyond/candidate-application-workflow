package org.kie.flyway.quarkus;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KieFlywayQuarkusRuntimeConfig$$accessor {
    private KieFlywayQuarkusRuntimeConfig$$accessor() {}
    @SuppressWarnings("unchecked")
    public static boolean get_enabled(Object __instance) {
        return ((KieFlywayQuarkusRuntimeConfig)__instance).enabled;
    }
    @SuppressWarnings("unchecked")
    public static void set_enabled(Object __instance, boolean enabled) {
        ((KieFlywayQuarkusRuntimeConfig)__instance).enabled = enabled;
    }
    @SuppressWarnings("unchecked")
    public static Object get_modules(Object __instance) {
        return ((KieFlywayQuarkusRuntimeConfig)__instance).modules;
    }
    @SuppressWarnings("unchecked")
    public static void set_modules(Object __instance, Object modules) {
        ((KieFlywayQuarkusRuntimeConfig)__instance).modules = (java.util.Map<String, org.kie.flyway.quarkus.KieFlywayQuarkusRuntimeConfig.KieQuarkusFlywayNamedModule>)modules;
    }
}
