package org.kie.kogito.svg.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnProcessSVGProcessor$$accessor {
    private KogitoAddOnProcessSVGProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnProcessSVGProcessor();
    }
}
