package org.kie.kogito.eventdriven.decision;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnEventDecisionProcessor$$accessor {
    private KogitoAddOnEventDecisionProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnEventDecisionProcessor();
    }
}
