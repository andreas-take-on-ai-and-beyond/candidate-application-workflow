package org.kie.kogito.addon.source.files.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnSourceFilesProcessor$$accessor {
    private KogitoAddOnSourceFilesProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnSourceFilesProcessor();
    }
}
