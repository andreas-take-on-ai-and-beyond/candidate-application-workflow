package org.kie.kogito.process.management.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnProcessManagementProcessor$$accessor {
    private KogitoAddOnProcessManagementProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnProcessManagementProcessor();
    }
}
