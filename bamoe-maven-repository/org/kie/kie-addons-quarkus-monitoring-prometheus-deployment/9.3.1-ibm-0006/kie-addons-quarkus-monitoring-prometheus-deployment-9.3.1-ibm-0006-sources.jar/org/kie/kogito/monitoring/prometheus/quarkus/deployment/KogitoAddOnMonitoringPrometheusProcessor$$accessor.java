package org.kie.kogito.monitoring.prometheus.quarkus.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnMonitoringPrometheusProcessor$$accessor {
    private KogitoAddOnMonitoringPrometheusProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnMonitoringPrometheusProcessor();
    }
}
