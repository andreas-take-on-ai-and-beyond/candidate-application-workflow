package org.kie.kogito.events.config;
@io.quarkus.Generated("Quarkus annotation processor")
public final class EventsRuntimeConfig$$accessor {
    private EventsRuntimeConfig$$accessor() {}
    @SuppressWarnings("unchecked")
    public static boolean get_processInstancesEventsEnabled(Object __instance) {
        return ((EventsRuntimeConfig)__instance).processInstancesEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static void set_processInstancesEventsEnabled(Object __instance, boolean processInstancesEventsEnabled) {
        ((EventsRuntimeConfig)__instance).processInstancesEventsEnabled = processInstancesEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static boolean get_processInstancesPropagate(Object __instance) {
        return ((EventsRuntimeConfig)__instance).processInstancesPropagate;
    }
    @SuppressWarnings("unchecked")
    public static void set_processInstancesPropagate(Object __instance, boolean processInstancesPropagate) {
        ((EventsRuntimeConfig)__instance).processInstancesPropagate = processInstancesPropagate;
    }
    @SuppressWarnings("unchecked")
    public static boolean get_processDefinitionEventsEnabled(Object __instance) {
        return ((EventsRuntimeConfig)__instance).processDefinitionEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static void set_processDefinitionEventsEnabled(Object __instance, boolean processDefinitionEventsEnabled) {
        ((EventsRuntimeConfig)__instance).processDefinitionEventsEnabled = processDefinitionEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static boolean get_processDefinitionPropagate(Object __instance) {
        return ((EventsRuntimeConfig)__instance).processDefinitionPropagate;
    }
    @SuppressWarnings("unchecked")
    public static void set_processDefinitionPropagate(Object __instance, boolean processDefinitionPropagate) {
        ((EventsRuntimeConfig)__instance).processDefinitionPropagate = processDefinitionPropagate;
    }
    @SuppressWarnings("unchecked")
    public static boolean get_userTasksEventsEnabled(Object __instance) {
        return ((EventsRuntimeConfig)__instance).userTasksEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static void set_userTasksEventsEnabled(Object __instance, boolean userTasksEventsEnabled) {
        ((EventsRuntimeConfig)__instance).userTasksEventsEnabled = userTasksEventsEnabled;
    }
    @SuppressWarnings("unchecked")
    public static boolean get_userTasksPropagate(Object __instance) {
        return ((EventsRuntimeConfig)__instance).userTasksPropagate;
    }
    @SuppressWarnings("unchecked")
    public static void set_userTasksPropagate(Object __instance, boolean userTasksPropagate) {
        ((EventsRuntimeConfig)__instance).userTasksPropagate = userTasksPropagate;
    }
}
