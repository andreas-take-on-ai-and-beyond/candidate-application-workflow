package org.kie.kogito.events.process.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnEventProcessProcessor$$accessor {
    private KogitoAddOnEventProcessProcessor$$accessor() {}
    public static Object construct() {
        return new KogitoAddOnEventProcessProcessor();
    }
}
