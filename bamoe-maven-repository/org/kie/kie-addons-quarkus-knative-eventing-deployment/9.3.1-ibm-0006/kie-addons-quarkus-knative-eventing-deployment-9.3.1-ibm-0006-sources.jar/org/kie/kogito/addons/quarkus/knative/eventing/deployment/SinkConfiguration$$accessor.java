package org.kie.kogito.addons.quarkus.knative.eventing.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class SinkConfiguration$$accessor {
    private SinkConfiguration$$accessor() {}
    @SuppressWarnings("unchecked")
    public static Object get_namespace(Object __instance) {
        return ((SinkConfiguration)__instance).namespace;
    }
    @SuppressWarnings("unchecked")
    public static void set_namespace(Object __instance, Object namespace) {
        ((SinkConfiguration)__instance).namespace = (java.util.Optional<String>)namespace;
    }
    @SuppressWarnings("unchecked")
    public static Object get_apiVersion(Object __instance) {
        return ((SinkConfiguration)__instance).apiVersion;
    }
    @SuppressWarnings("unchecked")
    public static void set_apiVersion(Object __instance, Object apiVersion) {
        ((SinkConfiguration)__instance).apiVersion = (String)apiVersion;
    }
    @SuppressWarnings("unchecked")
    public static Object get_name(Object __instance) {
        return ((SinkConfiguration)__instance).name;
    }
    @SuppressWarnings("unchecked")
    public static void set_name(Object __instance, Object name) {
        ((SinkConfiguration)__instance).name = (String)name;
    }
    @SuppressWarnings("unchecked")
    public static Object get_kind(Object __instance) {
        return ((SinkConfiguration)__instance).kind;
    }
    @SuppressWarnings("unchecked")
    public static void set_kind(Object __instance, Object kind) {
        ((SinkConfiguration)__instance).kind = (String)kind;
    }
}
