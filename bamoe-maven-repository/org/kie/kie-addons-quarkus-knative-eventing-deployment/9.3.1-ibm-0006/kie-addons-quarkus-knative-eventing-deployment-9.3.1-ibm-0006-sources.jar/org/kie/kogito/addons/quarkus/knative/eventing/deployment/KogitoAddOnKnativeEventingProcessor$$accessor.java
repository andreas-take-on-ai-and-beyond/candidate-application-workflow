package org.kie.kogito.addons.quarkus.knative.eventing.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAddOnKnativeEventingProcessor$$accessor {
    private KogitoAddOnKnativeEventingProcessor$$accessor() {}
    @SuppressWarnings("unchecked")
    public static Object get_config(Object __instance) {
        return ((KogitoAddOnKnativeEventingProcessor)__instance).config;
    }
    @SuppressWarnings("unchecked")
    public static void set_config(Object __instance, Object config) {
        ((KogitoAddOnKnativeEventingProcessor)__instance).config = (EventingConfiguration)config;
    }
}
