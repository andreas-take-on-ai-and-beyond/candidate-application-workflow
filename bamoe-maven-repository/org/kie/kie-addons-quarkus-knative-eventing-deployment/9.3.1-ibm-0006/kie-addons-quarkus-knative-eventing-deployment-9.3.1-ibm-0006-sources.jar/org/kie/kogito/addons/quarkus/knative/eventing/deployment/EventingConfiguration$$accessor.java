package org.kie.kogito.addons.quarkus.knative.eventing.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class EventingConfiguration$$accessor {
    private EventingConfiguration$$accessor() {}
    @SuppressWarnings("unchecked")
    public static Object get_broker(Object __instance) {
        return ((EventingConfiguration)__instance).broker;
    }
    @SuppressWarnings("unchecked")
    public static void set_broker(Object __instance, Object broker) {
        ((EventingConfiguration)__instance).broker = (String)broker;
    }
    @SuppressWarnings("unchecked")
    public static Object get_autoGenerateBroker(Object __instance) {
        return ((EventingConfiguration)__instance).autoGenerateBroker;
    }
    @SuppressWarnings("unchecked")
    public static void set_autoGenerateBroker(Object __instance, Object autoGenerateBroker) {
        ((EventingConfiguration)__instance).autoGenerateBroker = (Boolean)autoGenerateBroker;
    }
    @SuppressWarnings("unchecked")
    public static Object get_sink(Object __instance) {
        return ((EventingConfiguration)__instance).sink;
    }
    @SuppressWarnings("unchecked")
    public static void set_sink(Object __instance, Object sink) {
        ((EventingConfiguration)__instance).sink = (SinkConfiguration)sink;
    }
}
