package org.kie.kogito.index.jpa.mapper;

import javax.annotation.processing.Generated;
import org.kie.kogito.index.jpa.model.JobEntity;
import org.kie.kogito.index.model.Job;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.5.5.Final, compiler: javac, environment: Java 21.0.8 (IBM Corporation)"
)
public class JobEntityMapperImpl implements JobEntityMapper {

    @Override
    public JobEntity mapToEntity(Job job) {
        if ( job == null ) {
            return null;
        }

        JobEntity jobEntity = new JobEntity();

        jobEntity.setId( job.getId() );
        jobEntity.setProcessId( job.getProcessId() );
        jobEntity.setProcessInstanceId( job.getProcessInstanceId() );
        jobEntity.setRootProcessId( job.getRootProcessId() );
        jobEntity.setRootProcessInstanceId( job.getRootProcessInstanceId() );
        jobEntity.setExpirationTime( job.getExpirationTime() );
        jobEntity.setPriority( job.getPriority() );
        jobEntity.setCallbackEndpoint( job.getCallbackEndpoint() );
        jobEntity.setRepeatInterval( job.getRepeatInterval() );
        jobEntity.setRepeatLimit( job.getRepeatLimit() );
        jobEntity.setScheduledId( job.getScheduledId() );
        jobEntity.setRetries( job.getRetries() );
        jobEntity.setStatus( job.getStatus() );
        jobEntity.setLastUpdate( job.getLastUpdate() );
        jobEntity.setExecutionCounter( job.getExecutionCounter() );
        jobEntity.setEndpoint( job.getEndpoint() );
        jobEntity.setNodeInstanceId( job.getNodeInstanceId() );

        return jobEntity;
    }

    @Override
    public Job mapToModel(JobEntity job) {
        if ( job == null ) {
            return null;
        }

        Job job1 = new Job();

        job1.setId( job.getId() );
        job1.setProcessInstanceId( job.getProcessInstanceId() );
        job1.setRootProcessInstanceId( job.getRootProcessInstanceId() );
        job1.setProcessId( job.getProcessId() );
        job1.setRootProcessId( job.getRootProcessId() );
        job1.setExpirationTime( job.getExpirationTime() );
        job1.setPriority( job.getPriority() );
        job1.setCallbackEndpoint( job.getCallbackEndpoint() );
        job1.setRepeatInterval( job.getRepeatInterval() );
        job1.setRepeatLimit( job.getRepeatLimit() );
        job1.setScheduledId( job.getScheduledId() );
        job1.setRetries( job.getRetries() );
        job1.setStatus( job.getStatus() );
        job1.setLastUpdate( job.getLastUpdate() );
        job1.setExecutionCounter( job.getExecutionCounter() );
        job1.setEndpoint( job.getEndpoint() );
        job1.setNodeInstanceId( job.getNodeInstanceId() );

        return job1;
    }
}
