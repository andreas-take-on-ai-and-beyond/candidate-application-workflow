package org.kie.kogito.index.jpa.mapper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;
import org.kie.kogito.index.jpa.model.NodeEntity;
import org.kie.kogito.index.jpa.model.ProcessDefinitionEntity;
import org.kie.kogito.index.model.Node;
import org.kie.kogito.index.model.ProcessDefinition;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.5.5.Final, compiler: javac, environment: Java 21.0.8 (IBM Corporation)"
)
public class ProcessDefinitionEntityMapperImpl implements ProcessDefinitionEntityMapper {

    @Override
    public ProcessDefinitionEntity mapToEntity(ProcessDefinition pd) {
        if ( pd == null ) {
            return null;
        }

        ProcessDefinitionEntity processDefinitionEntity = new ProcessDefinitionEntity();

        processDefinitionEntity.setId( pd.getId() );
        processDefinitionEntity.setVersion( pd.getVersion() );
        processDefinitionEntity.setName( pd.getName() );
        Set<String> set = pd.getRoles();
        if ( set != null ) {
            processDefinitionEntity.setRoles( new LinkedHashSet<String>( set ) );
        }
        Set<String> set1 = pd.getAddons();
        if ( set1 != null ) {
            processDefinitionEntity.setAddons( new LinkedHashSet<String>( set1 ) );
        }
        processDefinitionEntity.setType( pd.getType() );
        processDefinitionEntity.setEndpoint( pd.getEndpoint() );
        processDefinitionEntity.setSource( map( pd.getSource() ) );
        processDefinitionEntity.setNodes( nodeListToNodeEntityList( pd.getNodes() ) );
        processDefinitionEntity.setDescription( pd.getDescription() );
        Set<String> set2 = pd.getAnnotations();
        if ( set2 != null ) {
            processDefinitionEntity.setAnnotations( new LinkedHashSet<String>( set2 ) );
        }
        processDefinitionEntity.setMetadata( map( pd.getMetadata() ) );

        afterMapping( processDefinitionEntity );

        return processDefinitionEntity;
    }

    @Override
    public ProcessDefinition mapToModel(ProcessDefinitionEntity pd) {
        if ( pd == null ) {
            return null;
        }

        ProcessDefinition processDefinition = new ProcessDefinition();

        processDefinition.setId( pd.getId() );
        processDefinition.setName( pd.getName() );
        Set<String> set = pd.getRoles();
        if ( set != null ) {
            processDefinition.setRoles( new LinkedHashSet<String>( set ) );
        }
        Set<String> set1 = pd.getAddons();
        if ( set1 != null ) {
            processDefinition.setAddons( new LinkedHashSet<String>( set1 ) );
        }
        processDefinition.setVersion( pd.getVersion() );
        processDefinition.setType( pd.getType() );
        processDefinition.setEndpoint( pd.getEndpoint() );
        processDefinition.setSource( map( pd.getSource() ) );
        processDefinition.setNodes( nodeEntityListToNodeList( pd.getNodes() ) );
        processDefinition.setDescription( pd.getDescription() );
        Set<String> set2 = pd.getAnnotations();
        if ( set2 != null ) {
            processDefinition.setAnnotations( new LinkedHashSet<String>( set2 ) );
        }
        processDefinition.setMetadata( map( pd.getMetadata() ) );

        return processDefinition;
    }

    protected NodeEntity nodeToNodeEntity(Node node) {
        if ( node == null ) {
            return null;
        }

        NodeEntity nodeEntity = new NodeEntity();

        nodeEntity.setId( node.getId() );
        nodeEntity.setName( node.getName() );
        nodeEntity.setUniqueId( node.getUniqueId() );
        nodeEntity.setType( node.getType() );
        Map<String, String> map = node.getMetadata();
        if ( map != null ) {
            nodeEntity.setMetadata( new LinkedHashMap<String, String>( map ) );
        }

        return nodeEntity;
    }

    protected List<NodeEntity> nodeListToNodeEntityList(List<Node> list) {
        if ( list == null ) {
            return null;
        }

        List<NodeEntity> list1 = new ArrayList<NodeEntity>( list.size() );
        for ( Node node : list ) {
            list1.add( nodeToNodeEntity( node ) );
        }

        return list1;
    }

    protected Node nodeEntityToNode(NodeEntity nodeEntity) {
        if ( nodeEntity == null ) {
            return null;
        }

        Node node = new Node();

        node.setId( nodeEntity.getId() );
        node.setName( nodeEntity.getName() );
        node.setType( nodeEntity.getType() );
        node.setUniqueId( nodeEntity.getUniqueId() );
        Map<String, String> map = nodeEntity.getMetadata();
        if ( map != null ) {
            node.setMetadata( new LinkedHashMap<String, String>( map ) );
        }

        return node;
    }

    protected List<Node> nodeEntityListToNodeList(List<NodeEntity> list) {
        if ( list == null ) {
            return null;
        }

        List<Node> list1 = new ArrayList<Node>( list.size() );
        for ( NodeEntity nodeEntity : list ) {
            list1.add( nodeEntityToNode( nodeEntity ) );
        }

        return list1;
    }
}
