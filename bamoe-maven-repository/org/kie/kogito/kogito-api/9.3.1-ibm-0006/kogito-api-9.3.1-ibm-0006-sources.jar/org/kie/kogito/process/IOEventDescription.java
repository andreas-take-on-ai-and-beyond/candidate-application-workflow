/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.process;

import java.util.Map;

public class IOEventDescription extends AbstractEventDescription<GroupedNamedDataType> {

    public IOEventDescription(String event, String nodeId, String nodeName, String eventType, String nodeInstanceId, String processInstanceId, GroupedNamedDataType dataType,
            Map<String, String> properties) {
        super(event, nodeId, nodeName, eventType, nodeInstanceId, processInstanceId, dataType, properties);
    }

    public IOEventDescription(String event, String nodeId, String nodeName, String eventType, String nodeInstanceId, String processInstanceId, GroupedNamedDataType dataType) {
        super(event, nodeId, nodeName, eventType, nodeInstanceId, processInstanceId, dataType);
    }

}
