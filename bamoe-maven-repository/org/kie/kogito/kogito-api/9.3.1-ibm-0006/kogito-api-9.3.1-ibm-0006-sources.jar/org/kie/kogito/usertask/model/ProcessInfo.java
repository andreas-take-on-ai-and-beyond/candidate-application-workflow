package org.kie.kogito.usertask.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessInfo {
    private String processInstanceId;
    private String processId;
    private String processVersion;

    private String parentProcessInstanceId;
    private String rootProcessId;
    private String rootProcessInstanceId;

    private ProcessInfo() {
    }

    private ProcessInfo(String processInstanceId, String processId, String processVersion) {
        this.processInstanceId = processInstanceId;
        this.processId = processId;
        this.processVersion = processVersion;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getProcessVersion() {
        return processVersion;
    }

    public void setProcessVersion(String processVersion) {
        this.processVersion = processVersion;
    }

    public String getParentProcessInstanceId() {
        return parentProcessInstanceId;
    }

    public void setParentProcessInstanceId(String parentProcessInstanceId) {
        this.parentProcessInstanceId = parentProcessInstanceId;
    }

    public String getRootProcessId() {
        return rootProcessId;
    }

    public void setRootProcessId(String rootProcessId) {
        this.rootProcessId = rootProcessId;
    }

    public String getRootProcessInstanceId() {
        return rootProcessInstanceId;
    }

    public void setRootProcessInstanceId(String rootProcessInstanceId) {
        this.rootProcessInstanceId = rootProcessInstanceId;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String processId;
        private String processVersion;
        private String processInstanceId;

        private String parentProcessInstanceId;
        private String rootProcessId;
        private String rootProcessInstanceId;

        public Builder withProcessId(String processId) {
            this.processId = processId;
            return this;
        }

        public Builder withProcessVersion(String processVersion) {
            this.processVersion = processVersion;
            return this;
        }

        public Builder withProcessInstanceId(String processInstanceId) {
            this.processInstanceId = processInstanceId;
            return this;
        }

        public Builder withParentProcessInstanceId(String parentProcessInstanceId) {
            this.parentProcessInstanceId = parentProcessInstanceId;
            return this;
        }

        public Builder withRootProcessId(String rootProcessId) {
            this.rootProcessId = rootProcessId;
            return this;
        }

        public Builder withRootProcessInstanceId(String rootProcessInstanceId) {
            this.rootProcessInstanceId = rootProcessInstanceId;
            return this;
        }

        public ProcessInfo build() {
            ProcessInfo processInfo = new ProcessInfo(processInstanceId, processId, processVersion);

            processInfo.setRootProcessInstanceId(rootProcessInstanceId);
            processInfo.setRootProcessId(rootProcessId);
            processInfo.setParentProcessInstanceId(parentProcessInstanceId);
            return processInfo;
        }
    }

}
