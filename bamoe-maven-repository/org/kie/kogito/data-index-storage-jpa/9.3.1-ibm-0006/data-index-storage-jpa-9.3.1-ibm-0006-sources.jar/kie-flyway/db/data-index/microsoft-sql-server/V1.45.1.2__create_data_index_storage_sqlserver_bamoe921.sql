ALTER TABLE nodes ADD retrigger BIT DEFAULT 0;

ALTER TABLE nodes ADD error_message character varying(max);

ALTER TABLE processes ADD node_instance_id character varying(255);

ALTER TABLE processes ADD cloud_event_id character varying(1000);

ALTER TABLE processes ADD cloud_event_source character varying(1000);