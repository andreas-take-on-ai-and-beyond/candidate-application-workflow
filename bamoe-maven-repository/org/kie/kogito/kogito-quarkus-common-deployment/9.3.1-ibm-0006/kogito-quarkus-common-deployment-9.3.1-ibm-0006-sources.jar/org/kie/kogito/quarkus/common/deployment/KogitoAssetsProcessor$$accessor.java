package org.kie.kogito.quarkus.common.deployment;
@io.quarkus.Generated("Quarkus annotation processor")
public final class KogitoAssetsProcessor$$accessor {
    private KogitoAssetsProcessor$$accessor() {}
    @SuppressWarnings("unchecked")
    public static Object get_root(Object __instance) {
        return ((KogitoAssetsProcessor)__instance).root;
    }
    @SuppressWarnings("unchecked")
    public static void set_root(Object __instance, Object root) {
        ((KogitoAssetsProcessor)__instance).root = (io.quarkus.deployment.builditem.ArchiveRootBuildItem)root;
    }
    @SuppressWarnings("unchecked")
    public static Object get_liveReload(Object __instance) {
        return ((KogitoAssetsProcessor)__instance).liveReload;
    }
    @SuppressWarnings("unchecked")
    public static void set_liveReload(Object __instance, Object liveReload) {
        ((KogitoAssetsProcessor)__instance).liveReload = (io.quarkus.deployment.builditem.LiveReloadBuildItem)liveReload;
    }
    @SuppressWarnings("unchecked")
    public static Object get_curateOutcomeBuildItem(Object __instance) {
        return ((KogitoAssetsProcessor)__instance).curateOutcomeBuildItem;
    }
    @SuppressWarnings("unchecked")
    public static void set_curateOutcomeBuildItem(Object __instance, Object curateOutcomeBuildItem) {
        ((KogitoAssetsProcessor)__instance).curateOutcomeBuildItem = (io.quarkus.deployment.pkg.builditem.CurateOutcomeBuildItem)curateOutcomeBuildItem;
    }
    @SuppressWarnings("unchecked")
    public static Object get_combinedIndexBuildItem(Object __instance) {
        return ((KogitoAssetsProcessor)__instance).combinedIndexBuildItem;
    }
    @SuppressWarnings("unchecked")
    public static void set_combinedIndexBuildItem(Object __instance, Object combinedIndexBuildItem) {
        ((KogitoAssetsProcessor)__instance).combinedIndexBuildItem = (io.quarkus.deployment.builditem.CombinedIndexBuildItem)combinedIndexBuildItem;
    }
    @SuppressWarnings("unchecked")
    public static Object get_outputTargetBuildItem(Object __instance) {
        return ((KogitoAssetsProcessor)__instance).outputTargetBuildItem;
    }
    @SuppressWarnings("unchecked")
    public static void set_outputTargetBuildItem(Object __instance, Object outputTargetBuildItem) {
        ((KogitoAssetsProcessor)__instance).outputTargetBuildItem = (io.quarkus.deployment.pkg.builditem.OutputTargetBuildItem)outputTargetBuildItem;
    }
}
