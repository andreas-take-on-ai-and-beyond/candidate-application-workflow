/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.quarkus.workflow.deployment.config;

import io.quarkus.runtime.annotations.ConfigItem;
import io.quarkus.runtime.annotations.ConfigPhase;
import io.quarkus.runtime.annotations.ConfigRoot;

@ConfigRoot(name = "kogito", phase = ConfigPhase.BUILD_TIME)
public class KogitoWorkflowBuildTimeConfig {

    /**
     * Configuration for DevServices. DevServices allows Quarkus to automatically start Data Index in dev and test mode.
     */
    @ConfigItem
    public KogitoDevServicesBuildTimeConfig devservices;

    /**
     * Always include the Workflow debug logger. By default, this will only be included in dev and test.
     * Setting this to true will also include the Workflow debug logger in Prod
     */
    @ConfigItem(name = "logger.always-include", defaultValue = "false")
    public boolean alwaysInclude;

}
